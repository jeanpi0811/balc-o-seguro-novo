# Termos de Uso — Balcão Seguro

**Versão:** 1.4.0
**Última atualização:** 18 de setembro de 2026

## 1. Finalidade

O Balcão Seguro é uma ferramenta de apoio ao atendimento farmacêutico. Ele organiza protocolos, alertas, consultas de medicamentos e registros locais para auxiliar o trabalho profissional.

## 2. Limites do aplicativo

O aplicativo não realiza diagnóstico médico, não substitui prescrição, não garante resultado clínico e não substitui bula, avaliação médica, julgamento farmacêutico, protocolos institucionais ou exigências sanitárias.

As informações apresentadas devem ser revisadas pelo profissional responsável antes de qualquer orientação. Devem ser confirmados, conforme o caso, a bula vigente, a dose, a forma farmacêutica, as contraindicações, as interações, as alergias, os sinais de alerta e as regras sanitárias aplicáveis.

Em situações graves, sinais de alerta ou dúvida clínica, o usuário deve seguir os protocolos locais e encaminhar a pessoa para serviço de saúde adequado.

## 3. Conteúdo farmacêutico

O responsável pelo conteúdo farmacêutico inicial é **Jean Pierre Andres — CRF/RS 15974**. Essa identificação não substitui a responsabilidade técnica da farmácia, drogaria, estabelecimento de saúde ou serviço em que o aplicativo seja utilizado.

A base local deve ser revisada e atualizada periodicamente. O aplicativo pode conter limitações, omissões ou necessidade de confirmação em fontes oficiais.

## 4. Registros locais

Os registros criados pelo usuário são armazenados localmente no aparelho. O usuário é responsável por inserir apenas informações necessárias, proteger o dispositivo e observar as normas profissionais e de proteção de dados aplicáveis ao seu contexto.

## 5. Compartilhamento

Quando o usuário usa a função de compartilhamento, ele escolhe o destino e confirma o envio. O tratamento do conteúdo pelo serviço escolhido é regido pelos termos e pela política de privacidade desse serviço.

## 6. Uso permitido

O aplicativo deve ser utilizado de maneira lícita, responsável e compatível com a formação profissional do usuário. É proibido utilizar o aplicativo para criar orientação deliberadamente falsa, violar direitos de terceiros ou contornar regras sanitárias.

## 7. Suporte

Dúvidas sobre o aplicativo podem ser encaminhadas ao suporte pelo WhatsApp **(54) 99142-7519**.

## 8. Aceite

Ao aceitar estes termos e utilizar o aplicativo, o usuário declara que compreendeu sua finalidade de apoio, seus limites e a necessidade de revisão profissional das informações apresentadas.

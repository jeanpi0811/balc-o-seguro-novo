# Próximas instruções — Balcão Seguro v1.2.6

## Acesso Admin

Acesse pelo app:

1. Aba **Mais**
2. **Administração do aplicativo**
3. **Entrar na Área Admin**
4. PIN: `274798`

Dentro da Área Admin você pode:

- liberar Pro neste aparelho;
- revogar Pro neste aparelho;
- zerar consultas grátis;
- exportar dados locais;
- limpar dados locais;
- conferir versão, base local, registros e ambiente.

## Status comercial

Esta versão é uma **demonstração comercial**. Ela serve para testar e mostrar o app antes da versão candidata para loja.

- Pagamento real: ainda não ativo.
- Pro: preparado e liberável via Admin.
- Próxima versão sugerida: `1.3.0` candidata para loja.

## Próximo passo técnico

Depois de validar esta versão em Android, iPhone e HTV/TV box, preparar:

- screenshots de loja;
- URL pública da Política de Privacidade;
- conta Apple Developer;
- Google Play Console;
- projeto RevenueCat;
- produtos: `balcao_pro_mensal`, `balcao_pro_anual`, `balcao_pro_vitalicio`.

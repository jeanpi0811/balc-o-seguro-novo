#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — validar ambiente Android"
echo "============================================"

ok=1
check_cmd() {
  if command -v "$1" >/dev/null 2>&1; then
    echo "OK: $1 -> $(command -v "$1")"
  else
    echo "FALTA: $1"
    ok=0
  fi
}

check_cmd node
check_cmd npm
check_cmd java
check_cmd unzip

if [ -n "${ANDROID_HOME:-}" ]; then
  echo "OK: ANDROID_HOME=$ANDROID_HOME"
elif [ -n "${ANDROID_SDK_ROOT:-}" ]; then
  echo "OK: ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT"
else
  echo "AVISO: ANDROID_HOME/ANDROID_SDK_ROOT não está definido. Android Studio geralmente resolve, mas se falhar configure o SDK."
fi

if [ -d "node_modules" ]; then
  echo "OK: node_modules existe"
else
  echo "AVISO: node_modules ainda não existe. Rode ./01_PREPARAR_DEPENDENCIAS.command"
fi

if [ "$ok" = "0" ]; then
  echo ""
  echo "Ambiente incompleto. No macOS, o mínimo costuma ser:"
  echo "brew install node openjdk@17"
  echo "Depois instale Android Studio e abra uma vez para baixar o SDK."
  exit 1
fi

echo ""
echo "Validação básica concluída."

# Como editar e evoluir o Balcão Seguro

## 1. Protocolos de triagem

Edite:

```text
src/data/protocolos.ts
```

Cada protocolo possui perguntas de risco amarelo/vermelho, conduta verde, amarela e vermelha, MIPs possíveis e itens a evitar.

Na versão final, o resultado só aparece depois que todas as perguntas do protocolo são respondidas.

## 2. Medicamentos

A tela usa este agregador:

```text
src/data/medicamentos.ts
```

Ele lê automaticamente:

```text
src/data/medicamentos.importados.json
src/data/medicamentos.sample.ts
```

O jeito mais simples de ampliar a base é editar o CSV e importar:

```bash
npm run import:csv
```

## 3. Build correto

Para entregar APK final:

```bash
./GERAR_APK_FINAL.command
```

Não entregue APK debug.

## 4. Próximas melhorias úteis

- PDF do atendimento.
- Cadastro opcional de paciente.
- Exportação CSV dos registros.
- Base Anvisa/CMED validada e maior.
- Tela de termos de uso.
- Senha local ou biometria para abrir registros.
- Assinatura/versão Pro apenas depois que o MVP estiver validado.

# Release de produção — Balcão Seguro 1.4.0

## Status executivo

A versão 1.4.0 está tecnicamente organizada para uma rodada de release candidate, mas **a publicação nas lojas ainda exige ações nas contas do desenvolvedor**. A configuração do app foi alinhada para Android e iOS, os metadados de versão foram atualizados e as validações locais de TypeScript e base de medicamentos passaram sem falhas.

A submissão final não deve ser feita antes de validar a assinatura definitiva, testar o AAB em aparelho real, hospedar a política de privacidade em uma URL pública e preencher as declarações de conteúdo, saúde, privacidade e classificação indicativa nos consoles.

## Alterações aplicadas

- Versão do aplicativo alinhada para **1.4.0**.
- Android `versionCode` alinhado para **21**.
- iOS `buildNumber` alinhado para **21**.
- Android configurado para `compileSdkVersion` e `targetSdkVersion` **36**, requisito de envio do Google Play a partir de 31 de agosto de 2026 para novos apps e atualizações.[1]
- Exportação de criptografia não isenta declarada no iOS (`ITSAppUsesNonExemptEncryption=false`), porque o aplicativo não implementa criptografia própria além dos mecanismos do sistema.
- Backup Android desativado na configuração do app, coerente com o armazenamento local de registros e com a política de privacidade.
- Permissões sensíveis desnecessárias permanecem bloqueadas.
- Política de privacidade final e termos de uso finais preparados.
- Workflow de release ajustado para produzir APK e AAB com nomes da versão 1.4.0.

## Google Play Console

1. Criar ou confirmar o aplicativo com o pacote `br.com.farmabolso.balcaoseguro`.
2. Publicar a política de privacidade em uma URL pública e substituir `privacyPolicyUrl` em `app.json`.
3. Preencher **Segurança dos dados**. Mesmo apps que não coletam nem compartilham dados precisam preencher o formulário e informar uma política de privacidade.[2]
4. Preencher a declaração de **App de saúde/medicina**. O Balcão Seguro oferece apoio a atendimento farmacêutico, consultas de medicamentos, triagem e interações; portanto, deve ser declarado de forma precisa no conteúdo do app.[3]
5. Informar que o app é uma ferramenta de apoio e não substitui avaliação profissional, diagnóstico ou tratamento.
6. Selecionar classificação indicativa adequada e responder às perguntas de conteúdo médico.
7. Cadastrar e-mail de suporte público. O WhatsApp pode ser mantido como canal adicional, mas um e-mail institucional é recomendado.
8. Gerar e enviar o **AAB**, não apenas o APK, para a faixa de teste interno.
9. Fazer teste interno ou fechado em pelo menos um aparelho Android físico.
10. Validar a instalação, abertura offline, busca de medicamentos, triagem, interação, registro, exportação manual e exclusão de dados locais.
11. Enviar ícone de alta resolução, screenshots reais e gráfico de recurso, conforme os campos exibidos pelo Play Console.
12. Confirmar a chave de upload definitiva e guardar o keystore e suas credenciais fora do repositório.
13. Só depois do teste interno, promover para produção.

## App Store Connect

1. Ter conta ativa no Apple Developer Program e criar o app com o bundle ID `br.com.farmabolso.balcaoseguro`.
2. Definir equipe, certificado de distribuição, provisioning profile e assinatura em um Mac com Xcode.
3. Gerar o projeto iOS com `npx expo prebuild -p ios` em ambiente macOS e revisar o projeto nativo gerado.
4. Subir um build com Xcode, Transporter ou ferramenta equivalente. A Apple associa o build ao app usando bundle ID, versão e build string presentes no pacote.[4]
5. Preencher o App Privacy com a declaração de que registros ficam no aparelho e não são enviados automaticamente pelo app, confirmando também bibliotecas de terceiros usadas no binário.
6. Informar URL de política de privacidade e URL de suporte acessível.
7. Enviar screenshots para iPhone e, se o suporte a iPad for mantido, para os tamanhos de iPad exigidos pelo App Store Connect.
8. Preencher idade, categoria, direitos de conteúdo, informações de contato e notas para a revisão.
9. Explicar nas notas de revisão que o app funciona offline, não exige login e é uma ferramenta de apoio farmacêutico.
10. Incluir uma conta de teste apenas se alguma funcionalidade futura passar a exigir login.
11. Confirmar que nenhuma tela apresenta promessa de diagnóstico, precisão clínica não comprovada ou cálculo de dose não respaldado. A Apple aplica análise mais rigorosa a apps médicos e exige avisos para decisões de saúde.[5]
12. Testar o build no TestFlight antes de enviar para revisão.

## Itens que não podem ser resolvidos somente no código

A URL pública da política, a conta de desenvolvedor, o e-mail institucional, a identidade legal do publicador, a chave Android definitiva, a assinatura Apple, os certificados, os screenshots capturados em aparelhos reais e as respostas nos formulários das lojas dependem dos dados e das contas do proprietário do aplicativo.

Não foram submetidos builds, nem enviados metadados para revisão, porque essas ações publicam o aplicativo e podem criar obrigações legais e comerciais.

## Validações executadas

- `npm run typecheck` — aprovado.
- `python3 scripts/validar_base_enriquecida.py` — aprovado, 5.200 itens, 0 falhas.
- `python3 scripts/validar_base_medicamentos.py` — executado; a base possui avisos de conteúdo que devem ser revisados antes de uso assistencial amplo.
- `git diff --check` — aprovado.

## Referências

[1]: https://developer.android.com/google/play/requirements/target-sdk?hl=pt-br "Requisito de nível de API alvo do Google Play"
[2]: https://support.google.com/googleplay/android-developer/answer/10787469?hl=pt-BR "Segurança dos dados do Google Play"
[3]: https://support.google.com/googleplay/android-developer/answer/13996367?hl=pt-BR "Categorias de apps de saúde do Google Play"
[4]: https://developer.apple.com/help/app-store-connect/manage-builds/upload-builds/ "Upload de builds no App Store Connect"
[5]: https://developer.apple.com/app-store/review/guidelines/ "Diretrizes de revisão da App Store"

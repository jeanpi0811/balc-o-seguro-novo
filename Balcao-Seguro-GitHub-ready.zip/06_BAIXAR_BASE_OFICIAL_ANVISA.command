#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p base_oficial_anvisa
URL="https://dados.anvisa.gov.br/dados/DADOS_ABERTOS_MEDICAMENTOS.csv"
DEST="base_oficial_anvisa/DADOS_ABERTOS_MEDICAMENTOS.csv"
echo "== Balcão Seguro: baixar base oficial Anvisa =="
echo "Fonte: $URL"
if command -v curl >/dev/null 2>&1; then
  curl -L --fail --retry 3 --connect-timeout 20 -o "$DEST" "$URL"
elif command -v python3 >/dev/null 2>&1; then
  python3 -c "import urllib.request; urllib.request.urlretrieve('$URL', '$DEST'); print('Baixado: $DEST')"
else
  echo "ERRO: precisa de curl ou python3."
  exit 1
fi
echo "Arquivo salvo em: $DEST"
echo "Próximo passo: ./07_IMPORTAR_BASE_OFICIAL_ANVISA.command"

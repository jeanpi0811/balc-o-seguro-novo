#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 <<'PY'
import json
from pathlib import Path
p=Path('app.json')
app=json.loads(p.read_text())
expo=app['expo']
expo.pop('plugins', None)
expo['splash']={'image':'./assets/splash.png','resizeMode':'contain','backgroundColor':'#0f172a'}
p.write_text(json.dumps(app,ensure_ascii=False,indent=2)+'\n')
print('app.json ajustado: splash legado, sem plugin obrigatório.')
PY

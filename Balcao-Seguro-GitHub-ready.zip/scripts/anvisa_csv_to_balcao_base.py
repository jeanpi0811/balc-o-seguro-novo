#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, re, unicodedata
from datetime import date
from pathlib import Path
ANVISA_CSV_URL = "https://dados.anvisa.gov.br/dados/DADOS_ABERTOS_MEDICAMENTOS.csv"
BULARIO_URL = "https://consultas.anvisa.gov.br/"
def norm(s: str) -> str:
    s = unicodedata.normalize("NFD", s or "")
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")
def pick(row: dict[str, str], *names: str) -> str:
    by_norm = {norm(k): v for k, v in row.items()}
    for name in names:
        v = by_norm.get(norm(name), "")
        if str(v).strip(): return str(v).strip()
    return ""
def slug(value: str) -> str:
    return norm(value).replace("_", "-") or "medicamento"
def guess_tarja(row: dict[str, str]) -> str:
    text = pick(row, "TARJA", "RESTRICAO_PRESCRICAO", "TIPO_RECEITUARIO").upper()
    if "PRETA" in text: return "Tarja preta"
    if "VERMELHA" in text: return "Tarja vermelha"
    if "CONTROLE" in text or "ESPECIAL" in text: return "Controle especial"
    if "MIP" in text or "ISENTO" in text: return "MIP"
    return "Outro"
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_csv"); ap.add_argument("output_json")
    ap.add_argument("--limit", type=int, default=500); ap.add_argument("--only-valid", action="store_true")
    ap.add_argument("--reviewer", default="Jean Pierre Andres — CRF/RS 15974")
    args = ap.parse_args(); src = Path(args.input_csv)
    if not src.exists(): raise SystemExit(f"CSV não encontrado: {src}")
    rows=[]
    for enc in ("latin1","utf-8-sig","utf-8"):
        try:
            with src.open("r", encoding=enc, newline="") as fh:
                sample=fh.read(4096); fh.seek(0); dialect=csv.Sniffer().sniff(sample, delimiters=";,\t"); rows=[dict(r) for r in csv.DictReader(fh, dialect=dialect)]
            break
        except UnicodeDecodeError: pass
    today=date.today().isoformat(); out=[]; seen=set()
    for row in rows:
        nome=pick(row,"NOME_PRODUTO","PRODUTO","MEDICAMENTO"); principio=pick(row,"PRINCIPIO_ATIVO","PRINCIPIO ATIVO","SUBSTANCIA")
        situacao=pick(row,"SITUACAO_REGISTRO","SITUAÇÃO_REGISTRO","SITUACAO"); registro=pick(row,"NUMERO_REGISTRO_PRODUTO","REGISTRO","NUMERO_REGISTRO")
        categoria=pick(row,"CATEGORIA_REGULATORIA","CATEGORIA"); empresa=pick(row,"EMPRESA_DETENTORA_REGISTRO","DETENTOR_REGISTRO","EMPRESA")
        data_registro=pick(row,"DATA_REGISTRO_PRODUTO","DATA_REGISTRO"); vencimento=pick(row,"DATA_VENCIMENTO_REGISTRO","VENCIMENTO_REGISTRO")
        apresentacao=pick(row,"APRESENTACAO","APRESENTAÇÃO","FORMA_FARMACEUTICA")
        if not nome or not principio: continue
        if args.only_valid and "VALID" not in unicodedata.normalize("NFD", situacao.upper()).encode("ascii","ignore").decode(): continue
        key=(nome.upper(), principio.upper(), registro)
        if key in seen: continue
        seen.add(key)
        out.append({"id":f"{slug(nome)}-{registro or len(out)+1}","nome":nome,"principioAtivo":principio,"classe":categoria or "Conferir classe terapêutica em bula/protocolo","tarja":guess_tarja(row),"forma":apresentacao or "Conferir apresentação do produto específico","dosagem":"Conferir concentração/apresentação e bula profissional do produto específico","referencia":"Conferir referência/generico/similar no Sistema de Consultas/Bulário Anvisa","genericos":[],"similaresIntercambiaveis":[],"alertas":["Item importado da base de registro. Alertas clínicos ainda devem ser validados em bula profissional."],"contraindicacoes":["Conferir contraindicações na bula profissional do produto específico."],"statusValidacao":"parcial" if situacao else "pendente","numeroRegistroAnvisa":registro,"situacaoRegistro":situacao,"categoriaRegulatoria":categoria,"detentorRegistro":empresa,"dataRegistro":data_registro,"dataVencimentoRegistro":vencimento,"revisadoEm":today,"revisadoPor":args.reviewer,"fontes":[{"tipo":"ANVISA_DADOS_ABERTOS","titulo":"Dados abertos da Anvisa — Medicamentos Registrados no Brasil","url":ANVISA_CSV_URL,"acessadoEm":today,"observacao":"Importação automática para rastreabilidade de registro sanitário."},{"tipo":"ANVISA_BULARIO","titulo":"Bulário Eletrônico da Anvisa","url":BULARIO_URL,"acessadoEm":today,"observacao":"Conferir bula do paciente e bula profissional antes de classificar como validado."}],"observacoesValidacao":["Registro sanitário rastreável; informação clínica ainda requer validação de bula profissional.","Marque como validado somente após conferir produto, concentração, bula e critérios clínicos."]})
        if len(out) >= args.limit: break
    dst=Path(args.output_json); dst.parent.mkdir(parents=True, exist_ok=True); dst.write_text(json.dumps(out, ensure_ascii=False, indent=2)+"
", encoding="utf-8")
    print(f"OK: {len(out)} medicamento(s) exportado(s) para {dst}")
    print("Atenção: revise a bula profissional antes de uso assistencial amplo.")
    return 0
if __name__ == "__main__": raise SystemExit(main())

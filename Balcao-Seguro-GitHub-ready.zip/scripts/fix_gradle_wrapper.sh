#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WRAPPER="$ROOT/android/gradle/wrapper/gradle-wrapper.properties"

if [[ -f "$WRAPPER" ]]; then
  sed -i 's#distributionUrl=.*#distributionUrl=https\\://services.gradle.org/distributions/gradle-8.13-bin.zip#' "$WRAPPER"
  echo "Gradle wrapper fixado em 8.13."
else
  echo "Wrapper Gradle não encontrado; execute expo prebuild primeiro." >&2
  exit 1
fi

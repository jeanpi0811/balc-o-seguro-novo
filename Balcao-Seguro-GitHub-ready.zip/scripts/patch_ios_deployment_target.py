#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
IOS_DIR = ROOT / "ios"
TARGET = "16.4"

def patch_podfile():
    podfile = IOS_DIR / "Podfile"
    if not podfile.exists():
        print("Aviso: ios/Podfile ainda não existe. Rode expo prebuild primeiro.")
        return

    text = podfile.read_text(encoding="utf-8")

    # Descomenta/substitui platform :ios
    if re.search(r"^\s*#?\s*platform\s+:ios\s*,\s*['\"][0-9.]+['\"]", text, flags=re.M):
        text = re.sub(
            r"^\s*#?\s*platform\s+:ios\s*,\s*['\"][0-9.]+['\"]",
            f"platform :ios, '{TARGET}'",
            text,
            count=1,
            flags=re.M,
        )
    else:
        text = f"platform :ios, '{TARGET}'\n" + text

    # Garante que o post_install force IPHONEOS_DEPLOYMENT_TARGET nos Pods
    marker = "BALCAO_SEGURO_FORCE_IOS_DEPLOYMENT_TARGET"
    if marker not in text:
        injection = f"""
  # {marker}
  installer.pods_project.targets.each do |target|
    target.build_configurations.each do |config|
      config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '{TARGET}'
    end
  end
"""
        if "post_install do |installer|" in text:
            text = text.replace("post_install do |installer|", "post_install do |installer|" + injection, 1)
        else:
            text += f"""

post_install do |installer|
{injection}
end
"""
    podfile.write_text(text, encoding="utf-8")
    print(f"OK: Podfile ajustado para iOS {TARGET}")

def patch_pbxproj_files():
    count = 0
    for pbxproj in IOS_DIR.glob("*.xcodeproj/project.pbxproj"):
        text = pbxproj.read_text(encoding="utf-8")
        new = re.sub(r"IPHONEOS_DEPLOYMENT_TARGET = [0-9.]+;", f"IPHONEOS_DEPLOYMENT_TARGET = {TARGET};", text)
        if new != text:
            pbxproj.write_text(new, encoding="utf-8")
            count += 1
    print(f"OK: {count} project.pbxproj ajustado(s) para iOS {TARGET}")

def main():
    if not IOS_DIR.exists():
        print("Aviso: pasta ios/ ainda não existe.")
        return
    patch_podfile()
    patch_pbxproj_files()

if __name__ == "__main__":
    main()

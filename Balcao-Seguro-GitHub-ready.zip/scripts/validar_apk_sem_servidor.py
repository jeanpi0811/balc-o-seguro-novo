#!/usr/bin/env python3
from pathlib import Path
import sys
import zipfile

if len(sys.argv) != 2:
    raise SystemExit('Uso: python3 scripts/validar_apk_sem_servidor.py caminho/do/app-release.apk')

apk = Path(sys.argv[1])
if not apk.exists():
    raise SystemExit(f'ERRO: APK não encontrado: {apk}')

with zipfile.ZipFile(apk) as z:
    nomes = z.namelist()

bundle_candidates = [n for n in nomes if n.endswith('index.android.bundle') or n.endswith('.bundle')]
dev_candidates = [n for n in nomes if any(x in n.lower() for x in ['devlauncher', 'dev-menu', 'debug'])]

print(f'Arquivo: {apk}')
print(f'Tamanho: {apk.stat().st_size / (1024 * 1024):.2f} MB')

if bundle_candidates:
    print('OK: bundle JS encontrado dentro do APK:')
    for item in bundle_candidates[:20]:
        print(f' - {item}')
else:
    raise SystemExit('ERRO: não encontrei index.android.bundle/assets JS no APK. Esse APK pode depender de Metro/dev server.')

if dev_candidates:
    print('AVISO: encontrei nomes com debug/dev. Nem sempre é erro, mas revise:')
    for item in dev_candidates[:20]:
        print(f' - {item}')
else:
    print('OK: não encontrei nomes óbvios de Dev Launcher/debug no APK.')

print('OK FINAL: APK aparenta ser release/offline e não deve pedir servidor Metro.')

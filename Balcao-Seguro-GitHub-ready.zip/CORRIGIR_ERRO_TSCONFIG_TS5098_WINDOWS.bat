@echo off
setlocal
cd /d "%~dp0"
title Balcao Seguro - corrigir tsconfig TS5098 / TS5101 / TS5107

echo == Balcao Seguro: corrigir tsconfig ==
> tsconfig.json echo {
>> tsconfig.json echo   "extends": "expo/tsconfig.base",
>> tsconfig.json echo   "compilerOptions": {
>> tsconfig.json echo     "strict": true,
>> tsconfig.json echo     "moduleResolution": "bundler",
>> tsconfig.json echo     "resolveJsonModule": true,
>> tsconfig.json echo     "esModuleInterop": true,
>> tsconfig.json echo     "skipLibCheck": true,
>> tsconfig.json echo     "jsx": "react-jsx",
>> tsconfig.json echo     "target": "ES2020",
>> tsconfig.json echo     "lib": ["DOM", "ES2020"],
>> tsconfig.json echo     "allowSyntheticDefaultImports": true,
>> tsconfig.json echo     "noEmit": true,
>> tsconfig.json echo     "ignoreDeprecations": "6.0"
>> tsconfig.json echo   },
>> tsconfig.json echo   "include": ["App.tsx", "src/**/*.ts", "src/**/*.tsx"],
>> tsconfig.json echo   "exclude": ["node_modules", "android", "ios", "build", "dist"]
>> tsconfig.json echo }

echo tsconfig.json corrigido. Rodando TypeScript agora...
call npm run typecheck
if errorlevel 1 (
  echo.
  echo Ainda ha erro no typecheck. Copie a saida ou mande o log.
  pause
  exit /b 1
)

echo.
echo OK. Agora rode o script de build do Windows ou Mac conforme seu ambiente.
pause

#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Correção ERESOLVE: usando instalador seguro atual."
./01_PREPARAR_DEPENDENCIAS.command

# Checklist de teste em Android físico

## Instalação
- [ ] Instala sem erro pelo APK final
- [ ] Não aparece tela vermelha do React Native
- [ ] Não pede Metro/Expo/dev server
- [ ] Abre em modo avião/offline

## Aparência
- [ ] Ícone aparece correto no launcher
- [ ] Splash aparece correto
- [ ] Textos não cortam em tela pequena
- [ ] Botões não ficam sobrepostos
- [ ] Status bar e área segura estão ok

## Funções
- [ ] Iniciar triagem funciona
- [ ] Resultado da triagem só aparece após responder o fluxo
- [ ] Busca de medicamentos funciona sem internet
- [ ] Troca segura abre corretamente
- [ ] Registro salva localmente
- [ ] Limpar registros funciona
- [ ] Compartilhar registro funciona
- [ ] Telas Sobre/Termos/Privacidade/Fontes abrem

## Segurança
- [ ] App não pede permissões desnecessárias
- [ ] Dados não são enviados automaticamente
- [ ] Avisos de responsabilidade aparecem
- [ ] Casos graves são orientados para atendimento adequado

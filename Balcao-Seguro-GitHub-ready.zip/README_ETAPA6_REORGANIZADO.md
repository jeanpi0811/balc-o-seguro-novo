# Balcão Seguro — versão reorganizada

Esta versão foi reorganizada para ficar mais didática e menos confusa no uso real do balcão.

## Abas principais

- **Início**: resumo do app, atalhos principais e fluxo recomendado.
- **Atendimento**: inicia o atendimento guiado e mostra o fluxo correto.
- **Medicamentos**: busca offline com resumo e detalhes expansíveis.
- **Interações**: checagem inicial entre dois medicamentos.
- **Mais**: sobre, privacidade, termos, fontes, registros e troca segura.

## Atendimento guiado

O atendimento agora começa pelo perfil do paciente:

- Adulto
- Criança
- Idoso
- Gestante
- Lactante

Também permite marcar fatores de risco, como alergia, anticoagulante, doença renal, doença hepática, hipertensão, diabetes e polimedicação.

Essas informações entram no registro salvo.

## Gerar APK direto

Use:

```bash
chmod +x *.command
./GERAR_APK_FINAL_REORGANIZADO.command
```

O arquivo final esperado é:

```text
Balcao-Seguro-v1.0.0-final.apk
```

Este APK pode ser copiado para o Android físico e instalado manualmente.

## Aviso

O app é ferramenta de apoio. Não substitui julgamento farmacêutico, bula profissional, protocolos institucionais, legislação sanitária nem atendimento médico quando indicado.

## Correção de dependências — etapa 6B

Se aparecer o erro `No matching version found for expo-splash-screen@~32.0.0`, rode:

```bash
./CORRIGIR_ERRO_EXPO_SPLASH_SCREEN.command
```

Depois gere o APK novamente:

```bash
./GERAR_APK_FINAL_REORGANIZADO.command
```

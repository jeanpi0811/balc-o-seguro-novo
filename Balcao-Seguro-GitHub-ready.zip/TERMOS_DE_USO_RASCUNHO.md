# Termos de Uso — Balcão Seguro

Versão: 1.0.0
Responsável pelo conteúdo farmacêutico inicial: Jean Pierre Andres — CRF/RS 15974
Contato de suporte: WhatsApp (54) 99142-7519

O Balcão Seguro é uma ferramenta de apoio ao atendimento farmacêutico. Ele organiza protocolos, alertas e registros locais, mas não realiza diagnóstico, prescrição automática ou substituição do julgamento profissional.

A identificação do farmacêutico responsável no app se refere ao conteúdo/curadoria inicial do produto. Ela não substitui responsabilidade técnica de farmácia, drogaria, estabelecimento de saúde, serviço de terceiros, protocolos institucionais ou exigências sanitárias específicas.

O profissional responsável pelo atendimento deve revisar as informações apresentadas, confirmar bula, dose, forma farmacêutica, contraindicações, interações, alergias, sinais de alerta e regras sanitárias aplicáveis.

Em situações graves, sinais de alerta ou dúvida, o atendimento deve ser encaminhado conforme protocolos locais e serviços de saúde disponíveis.

A base local de medicamentos e protocolos deve ser validada periodicamente antes de uso assistencial amplo.

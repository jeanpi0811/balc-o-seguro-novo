# Como configurar PagSeguro/PagBank no Premium

## Modelo inicial sem servidor

Este app foi preparado para abrir links externos de pagamento do PagSeguro/PagBank.

Arquivo a editar:

```txt
src/data/premium.ts
```

Preencha o campo `pagSeguroUrl` de cada plano:

```ts
pagSeguroUrl: 'COLE_AQUI_O_LINK_DO_PLANO_NO_PAGSEGURO'
```

Planos já criados no app:

- Premium Vitalício: R$ 49,90
- Premium Mensal: R$ 9,90
- Premium Anual: R$ 89,90

## Como o usuário pagará

1. O usuário abre a aba Premium.
2. Toca no plano desejado.
3. O app abre o link externo seguro do PagSeguro/PagBank.
4. O usuário paga por Pix, cartão, boleto ou meio disponível no checkout/link escolhido.
5. Na primeira fase, a liberação pode ser manual: usuário envia comprovante pelo WhatsApp.

## Por que não colocar token do PagSeguro dentro do APK?

Não coloque token, chave privada ou credencial PagSeguro dentro do APK. APK pode ser inspecionado por terceiros.
Para liberação automática, use servidor/webhook, função serverless ou Google Play Billing.

## Modelo recomendado para Play Store

Se a venda for de recurso digital usado dentro do app publicado pela Google Play, o caminho mais seguro para aprovação é Google Play Billing.

## Modelo recomendado fora da Play Store

Para APK distribuído diretamente, o caminho mais simples é PagSeguro/PagBank por Link de Pagamento ou Checkout externo, com validação manual ou webhook em fase posterior.

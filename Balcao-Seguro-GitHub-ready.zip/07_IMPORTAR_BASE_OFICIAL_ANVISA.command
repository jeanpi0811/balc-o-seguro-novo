#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CSV="base_oficial_anvisa/DADOS_ABERTOS_MEDICAMENTOS.csv"
OUT="src/data/medicamentos.importados.json"
echo "== Balcão Seguro: importar CSV oficial Anvisa para base local validável =="
if [ ! -f "$CSV" ]; then
  echo "ERRO: não encontrei $CSV"
  echo "Execute antes: ./06_BAIXAR_BASE_OFICIAL_ANVISA.command"
  exit 1
fi
python3 scripts/anvisa_csv_to_balcao_base.py "$CSV" "$OUT" --limit 500 --only-valid
echo "Base atualizada em: $OUT"
echo "Agora rode: npm run typecheck"
echo "Depois compile: ./02_GERAR_APK_DIRETO_ASSINADO.command"

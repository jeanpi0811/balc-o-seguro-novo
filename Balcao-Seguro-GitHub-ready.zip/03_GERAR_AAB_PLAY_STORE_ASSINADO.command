#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

export EXPO_NO_TELEMETRY=1
LOG="03-aab-playstore-final-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee "$LOG") 2>&1

echo "============================================"
echo " Balcão Seguro — AAB Play Store final assinado"
echo "============================================"
echo "Log: $LOG"

./00_VALIDAR_AMBIENTE_ANDROID.command

if [ ! -d "node_modules" ]; then
  ./01_PREPARAR_DEPENDENCIAS.command
else
  npx tsc --noEmit
fi

echo "== Preservando keystore antes do prebuild limpo =="
bash ./scripts/preserve_existing_keystore.sh || true

echo "== Gerando Android nativo limpo =="
npx expo prebuild -p android --clean

echo "== Ajustando AndroidManifest para privacidade/local =="
python3 ./scripts/patch_android_manifest.py

echo "== Criando/conferindo chave de upload =="
bash ./scripts/ensure_keystore.sh

echo "== Ajustando Gradle para usar assinatura release =="
python3 ./scripts/patch_android_signing.py

echo "== Compilando Android App Bundle =="
cd android
chmod +x ./gradlew
./gradlew bundleRelease
cd ..

AAB="android/app/build/outputs/bundle/release/app-release.aab"
if [ ! -f "$AAB" ]; then
  echo "ERRO: AAB não encontrado em $AAB"
  exit 1
fi
cp "$AAB" "Balcao-Seguro-v1.0.0-playstore.aab"

echo ""
echo "AAB final gerado:"
echo "Balcao-Seguro-v1.0.0-playstore.aab"
echo ""
echo "Este é o arquivo para envio no Google Play Console."

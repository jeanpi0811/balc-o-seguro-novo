@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo == Balcao Seguro: corrigir erro NPM ERESOLVE no Windows ==
where node >nul 2>&1 || (echo ERRO: Node nao encontrado.& pause & exit /b 1)
where npm >nul 2>&1 || (echo ERRO: npm nao encontrado.& pause & exit /b 1)
node -v
npm -v

echo Gravando package.json corrigido...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$pkg = @'
{
  "name": "balcao-seguro",
  "version": "1.0.0",
  "private": true,
  "main": "expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios",
    "web": "expo start --web",
    "check": "npx expo-doctor",
    "import:csv": "node scripts/importar_csv_node.mjs sample-data/medicamentos.csv src/data/medicamentos.importados.json",
    "prebuild:ios": "expo prebuild -p ios",
    "prebuild:android": "expo prebuild -p android",
    "open:ios": "xed ios",
    "apk:local": "cd android && ./gradlew assembleRelease",
    "prebuild:ios:offline": "expo prebuild -p ios --no-install",
    "prebuild:android:offline": "expo prebuild -p android --no-install",
    "apk:offline": "cd android && ./gradlew assembleRelease --offline",
    "typecheck": "tsc --noEmit",
    "validate": "npm run typecheck",
    "prebuild:android:clean": "expo prebuild -p android --clean",
    "apk:release": "cd android && ./gradlew assembleRelease",
    "aab:release": "cd android && ./gradlew bundleRelease",
    "final:check": "npm run typecheck && npx expo-doctor",
    "apk:final": "bash ./02_GERAR_APK_DIRETO_ASSINADO.command",
    "aab:final": "bash ./03_GERAR_AAB_PLAY_STORE_ASSINADO.command",
    "build:final": "bash ./GERAR_APK_E_AAB_FINAL.command",
    "verify:apk": "bash ./05_VERIFICAR_APK_GERADO.command",
    "validate:base": "python3 scripts/validar_base_medicamentos.py",
    "prebuild:check": "bash ./09_VALIDAR_PRE_BUILD.command",
    "build:final:log": "bash ./10_GERAR_APK_AAB_COM_LOG.command"
  },
  "dependencies": {
    "expo": "^56.0.0",
    "react": "19.2.3",
    "react-native": "0.85.0",
    "@react-native-async-storage/async-storage": "3.1.1"
  },
  "devDependencies": {
    "@types/react": "^19.2.0",
    "typescript": "^6.0.0",
    "babel-preset-expo": "^56.0.0"
  }
}
'@; Set-Content -LiteralPath package.json -Value $pkg -Encoding UTF8"

echo fund=false>.npmrc
echo audit=false>>.npmrc
echo legacy-peer-deps=false>>.npmrc

echo Limpando node_modules e package-lock...
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /f /q package-lock.json

echo Instalando dependencias corrigidas...
call npm install
if errorlevel 1 (
  echo npm install ainda falhou. Tentando expo install --fix mesmo assim...
)
call npx expo install --fix
call npm run typecheck
call npx expo-doctor

echo Pronto. Agora tente gerar APK/AAB com o script principal.
pause

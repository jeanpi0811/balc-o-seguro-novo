# Correção etapa 5B — npm ERESOLVE

O log enviado parou no `npm install`, antes de chegar ao Android/Gradle.

Causa: conflito entre React e React Native:

- projeto estava com `react@19.2.0`
- `react-native@0.85.0` exige `react@^19.2.3`

Correções aplicadas:

- `react` atualizado para `19.2.3`
- dependências deixadas compatíveis com Expo SDK 56
- removido uso de `latest` nas dependências principais
- criado script `CORRIGIR_ERRO_NPM_ERESOLVE.command`
- `09_VALIDAR_PRE_BUILD.command` agora chama a correção automaticamente quando `node_modules` não existir
- criado `CORRIGIR_ERRO_NPM_ERESOLVE_WINDOWS.bat` para Windows

No Mac:

```bash
chmod +x *.command scripts/*.sh scripts/*.py
./CORRIGIR_ERRO_NPM_ERESOLVE.command
./10_GERAR_APK_AAB_COM_LOG.command
```

Se aparecer erro estranho usando Node 26, use Node 22 LTS. A referência do Expo SDK 56 lista Node mínimo 22.13.x.

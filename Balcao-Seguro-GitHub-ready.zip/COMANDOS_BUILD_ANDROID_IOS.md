# Comandos de build — Android e iOS

## Entrar na pasta

```bash
cd "$HOME/Desktop/balcao-seguro-github-pronto" || cd "$HOME/Desktop/balcao-seguro-github-pronto 2"
```

## Instalar dependências

```bash
npm install
npx expo install --fix
```

## Gerar Android + iOS

```bash
npx expo prebuild
```

Se o `pod install` falhar, use:

```bash
npx expo prebuild --no-install
```

## iOS

```bash
cd ios
RCT_USE_PREBUILT_RNCORE=0 pod install --repo-update
cd ..
perl -0pi -e 's/ENABLE_USER_SCRIPT_SANDBOXING = YES;/ENABLE_USER_SCRIPT_SANDBOXING = NO;/g' ios/BalcoSeguro.xcodeproj/project.pbxproj
open ios/*.xcworkspace
```

No Xcode: **Product > Clean Build Folder** e depois **Run** no iPhone.

## Android APK mais rápido para arm64-v8a

```bash
cd android
chmod +x gradlew
./gradlew assembleRelease -PreactNativeArchitectures=arm64-v8a
```

## Android APK compatível com arm64-v8a e armeabi-v7a

```bash
cd android
chmod +x gradlew
./gradlew assembleRelease -PreactNativeArchitectures=arm64-v8a,armeabi-v7a
```

## AAB para Play Store

```bash
cd android
./gradlew bundleRelease
```

## Onde encontrar os arquivos

APK:

```text
android/app/build/outputs/apk/release/
```

AAB:

```text
android/app/build/outputs/bundle/release/app-release.aab
```

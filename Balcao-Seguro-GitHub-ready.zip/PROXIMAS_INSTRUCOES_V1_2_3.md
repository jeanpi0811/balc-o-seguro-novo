# Próximas instruções — Balcão Seguro v1.2.3

## 1. Instalar dependências

Na pasta do projeto:

```bash
cd ~/Desktop/balcao-seguro-github-pronto
npm install
npx expo install --fix
```

## 2. Rodar no Expo para teste rápido

```bash
npx expo start --clear
```

## 3. Gerar iOS e Android nativos

```bash
npx expo prebuild
```

## 4. iOS no Xcode

```bash
cd ios
pod install
cd ..
open ios/*.xcworkspace
```

No Xcode:

1. Product > Clean Build Folder
2. Selecione o iPhone físico
3. Run em Debug

Se voltar erro de EPERM/main.jsbundle, rode:

```bash
rm -rf ~/Library/Developer/Xcode/DerivedData/BalcoSeguro-*
sudo chown -R "$USER":staff .
chmod -R u+rwX .
xattr -dr com.apple.quarantine .
perl -0pi -e 's/ENABLE_USER_SCRIPT_SANDBOXING = YES;/ENABLE_USER_SCRIPT_SANDBOXING = NO;/g' ios/BalcoSeguro.xcodeproj/project.pbxproj
```

## 5. Testar alterações no app

Verifique:

- Aba "Atendimento" com ícone de atendimento/suporte.
- Aba "Medicamentos" com ícone de pílula.
- Aba "Planos Pro" substituindo o discurso de PagSeguro por Apple/Google.
- Área Dev oculta:
  - abrir aba Mais;
  - tocar 5 vezes no texto "Versão atual...";
  - inserir PIN 274798.

## 6. Android APK/AAB

APK release:

```bash
cd android
./gradlew assembleRelease
```

AAB para Play Store:

```bash
cd android
./gradlew bundleRelease
```

## 7. O que ainda falta para cobrança real

A versão 1.2.3 deixa a interface e os IDs preparados, mas ainda não conecta compras reais.

Para ativar cobrança real depois:

1. Criar conta Apple Developer.
2. Criar app no App Store Connect.
3. Criar produtos:
   - balcao_pro_mensal — assinatura mensal
   - balcao_pro_anual — assinatura anual
   - balcao_pro_vitalicio — compra única não consumível
4. Criar conta Google Play Console.
5. Criar os mesmos produtos no Google Play Console.
6. Criar projeto no RevenueCat.
7. Configurar entitlement `pro` e offering `default`.
8. Preencher as chaves públicas em `src/data/billingConfig.ts`.
9. Adicionar e conectar o SDK `react-native-purchases`.

Não coloque token secreto, senha ou chave privada dentro do app.

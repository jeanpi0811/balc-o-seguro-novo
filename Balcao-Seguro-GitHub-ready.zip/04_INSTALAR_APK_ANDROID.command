#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

APK="${1:-Balcao-Seguro-v1.0.0-final.apk}"

if ! command -v adb >/dev/null 2>&1; then
  echo "ERRO: adb não encontrado. Instale Android Platform Tools ou Android Studio."
  exit 1
fi
if [ ! -f "$APK" ]; then
  echo "ERRO: APK não encontrado: $APK"
  echo "Gere antes com: ./02_GERAR_APK_DIRETO_ASSINADO.command"
  exit 1
fi

adb devices
adb install -r "$APK"

echo ""
echo "Instalado. Abra o app Balcão Seguro no Android e teste offline."

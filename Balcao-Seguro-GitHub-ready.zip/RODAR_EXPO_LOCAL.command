#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -d "node_modules" ]; then
  echo "ERRO: node_modules não existe. Rode PREPARAR_CACHE_ONLINE_UMA_VEZ.command pelo menos uma vez."
  exit 1
fi

./node_modules/.bin/expo start --localhost

# Título e categoria sugeridos

## Nome do app
Balcão Seguro

## Nome curto
Balcão Seguro

## Categoria sugerida
Medical / Saúde e fitness

## Tags/termos úteis
farmácia, farmacêutico, triagem, medicamentos, orientação farmacêutica, atendimento, balcão, uso racional de medicamentos

## Público-alvo recomendado
Profissionais e estudantes da área farmacêutica. Evitar posicionar como app de automedicação para leigos.

# Política de Privacidade — Balcão Seguro

**Última atualização:** 18 de setembro de 2026
**Versão do aplicativo:** 1.4.0

O Balcão Seguro é um aplicativo offline de apoio ao atendimento farmacêutico. Esta política explica quais informações são tratadas pelo aplicativo, onde elas ficam armazenadas e em quais situações podem ser compartilhadas.

## 1. Dados tratados

O aplicativo pode armazenar localmente no aparelho registros criados pelo próprio usuário durante atendimentos. Esses registros podem conter informações digitadas pelo usuário sobre a orientação prestada e o contexto do atendimento.

O aplicativo não exige criação de conta, login ou cadastro em servidor. Nesta versão, não há envio automático desses registros para servidores do desenvolvedor.

A base de medicamentos e os protocolos locais são conteúdo do aplicativo. Eles não constituem dados pessoais do usuário.

## 2. Armazenamento e segurança

Os registros são mantidos no armazenamento local do dispositivo. O usuário deve proteger o aparelho com bloqueio de tela, senha e os recursos de segurança disponíveis no sistema operacional.

Como os dados ficam no aparelho, o usuário também é responsável por avaliar os riscos de backup, restauração, compartilhamento e acesso por outras pessoas com acesso ao dispositivo.

## 3. Compartilhamento iniciado pelo usuário

O usuário pode escolher compartilhar manualmente um registro ou uma exportação usando os recursos do sistema operacional. Nesse caso, o conteúdo é enviado ao destino escolhido pelo usuário, como aplicativo de mensagens, e-mail ou armazenamento em nuvem. O tratamento posterior passa a seguir as políticas do serviço escolhido.

O Balcão Seguro não envia registros automaticamente para terceiros e não usa os registros locais para publicidade, criação de perfil ou venda de dados.

## 4. Permissões e tecnologias de terceiros

A configuração atual não solicita permissões sensíveis de câmera, localização, contatos, microfone ou armazenamento externo. O aplicativo não usa anúncios, rastreamento publicitário, analytics ou login de terceiros nesta versão.

Se uma versão futura incluir servidor, analytics, crash reports, publicidade, sincronização, conta de usuário ou integração externa, esta política será atualizada antes da distribuição dessa versão.

## 5. Dados de saúde e uso profissional

O usuário deve evitar registrar dados pessoais sensíveis desnecessários. O aplicativo é uma ferramenta de apoio e organização. Ele não substitui avaliação médica, julgamento farmacêutico, bula, protocolos institucionais, legislação sanitária ou atendimento de emergência.

## 6. Crianças

O aplicativo não é direcionado a crianças e não foi projetado para coletar dados de crianças.

## 7. Direitos e solicitações

Como os registros são armazenados localmente e não são enviados automaticamente ao desenvolvedor, solicitações de acesso, correção ou exclusão devem ser realizadas no próprio aparelho, usando as funções disponíveis no aplicativo ou removendo os dados locais do aplicativo e do dispositivo.

Para dúvidas sobre esta política ou sobre o conteúdo farmacêutico, entre em contato:

**Jean Pierre Andres — CRF/RS 15974**
**Suporte:** WhatsApp (54) 99142-7519

## 8. Alterações desta política

Esta política poderá ser atualizada quando houver mudança no funcionamento do aplicativo, nas tecnologias utilizadas ou nas exigências legais e das lojas de aplicativos. A data de atualização será modificada no início deste documento.

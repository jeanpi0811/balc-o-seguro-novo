# Checklist de publicação — Google Play Console

## Identidade do app

- [ ] Confirmar nome público: **Balcão Seguro**.
- [ ] Confirmar pacote: `br.com.farmabolso.balcaoseguro`.
- [ ] Confirmar versão: **1.4.0** / `versionCode 21`.
- [ ] Confirmar categoria e classificação indicativa.
- [ ] Confirmar publicador legal e dados de contato.

## Conteúdo e políticas

- [ ] Hospedar `politica_privacidade_publicar.md` em uma URL pública.
- [ ] Inserir a URL pública de privacidade no Play Console e em `app.json`.
- [ ] Preencher a seção **Segurança dos dados**.
- [ ] Declarar que o app não envia registros automaticamente para servidor.
- [ ] Declarar o compartilhamento manual iniciado pelo usuário.
- [ ] Preencher a declaração de **App de saúde/medicina**.
- [ ] Informar claramente que o app é apoio profissional e não substitui diagnóstico, prescrição ou avaliação médica.
- [ ] Preencher classificação indicativa e questionário de conteúdo.
- [ ] Fornecer e-mail de suporte público e canal adicional de WhatsApp.

## Binário e testes

- [ ] Configurar a keystore de upload definitiva em segredo do GitHub.
- [ ] Gerar o AAB de produção da versão 1.4.0.
- [ ] Verificar `targetSdkVersion 36`.
- [ ] Instalar o AAB pela faixa de teste interno.
- [ ] Testar em aparelho Android físico.
- [ ] Testar funcionamento offline.
- [ ] Testar busca, triagem, interações, atendimento, registro, exportação manual e limpeza local.
- [ ] Revisar avisos farmacêuticos e conteúdo da base antes do uso assistencial.

## Materiais da loja

- [ ] Ícone de alta resolução 512×512.
- [ ] Screenshots reais atualizados da versão 1.4.0.
- [ ] Gráfico de recurso 1024×500, se solicitado pelo console.
- [ ] Título, descrição curta e descrição completa revisados.
- [ ] Notas da versão 1.4.0 preparadas.

## Publicação

- [ ] Enviar primeiro para teste interno.
- [ ] Revisar avisos e relatórios do Play Console.
- [ ] Promover para teste fechado, se necessário.
- [ ] Enviar para produção somente após aprovação do teste real.

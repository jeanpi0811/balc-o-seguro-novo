# Etapa 8 — Banco de dados enriquecido

Esta versão adiciona a base `src/data/medicamentos.enriquecidos.json` com campos estruturados para deixar o Balcão Seguro mais didático e seguro no atendimento.

## O que foi enriquecido

- 27 medicamentos/princípios ativos já existentes na base local.
- Uso orientativo em linguagem simples.
- Grupos especiais: crianças, idosos, gestantes, lactantes, renal, hepático, hipertensão, diabetes, cardiopatia, anticoagulantes e alergias.
- Interações relevantes com gravidade, mecanismo simples, consequência e orientação segura.
- Efeitos adversos separados por comuns, importantes, alergia, intoxicação e atendimento imediato.
- Perguntas obrigatórias e recomendadas para triagem farmacêutica.
- Resumo leigo: para que serve, quando ter cuidado, quando procurar atendimento e o que não fazer.
- Fontes para conferência e status de validação.

## Importante

A base enriquecida foi construída como checklist conservador de apoio, não como bula final de cada produto. Para publicação assistencial ampla, revise manualmente produto por produto no Bulário/Sistema de Consultas da Anvisa e marque como validado somente depois da revisão técnica.

## Validar a base

```bash
./VALIDAR_BASE_ENRIQUECIDA.command
```

## Gerar APK

```bash
chmod +x *.command
chmod +x scripts/*.sh
./VALIDAR_BASE_ENRIQUECIDA.command
./GERAR_APK_FINAL_REORGANIZADO.command
```

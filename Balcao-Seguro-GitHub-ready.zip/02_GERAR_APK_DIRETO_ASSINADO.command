#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

export EXPO_NO_TELEMETRY=1
LOG="02-apk-direto-final-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee "$LOG") 2>&1

echo "============================================"
echo " Balcão Seguro — APK direto final assinado"
echo "============================================"
echo "Log: $LOG"

./00_VALIDAR_AMBIENTE_ANDROID.command

if [ ! -d "node_modules" ]; then
  ./01_PREPARAR_DEPENDENCIAS.command
else
  npx tsc --noEmit
  python3 scripts/validar_base_enriquecida.py
fi

echo "== Preservando keystore antes do prebuild limpo =="
bash ./scripts/preserve_existing_keystore.sh || true

echo "== Gerando Android nativo limpo =="
npx expo prebuild -p android --clean

echo "== Ajustando AndroidManifest para privacidade/local =="
python3 ./scripts/patch_android_manifest.py

echo "== Criando/conferindo chave release =="
bash ./scripts/ensure_keystore.sh

echo "== Ajustando Gradle para usar assinatura release =="
python3 ./scripts/patch_android_signing.py

echo "== Compilando APK release =="
cd android
chmod +x ./gradlew
./gradlew assembleRelease
cd ..

APK="android/app/build/outputs/apk/release/app-release.apk"
if [ ! -f "$APK" ]; then
  echo "ERRO: APK não encontrado em $APK"
  exit 1
fi
cp "$APK" "Balcao-Seguro-v1.1.6-release-sem-servidor.apk"

echo "== Conferindo APK =="
./05_VERIFICAR_APK_GERADO.command "Balcao-Seguro-v1.1.6-release-sem-servidor.apk" || true

echo ""
echo "APK final gerado:"
echo "Balcao-Seguro-v1.1.6-release-sem-servidor.apk"
echo ""
echo "Instalação no Android via cabo:"
echo "adb install -r Balcao-Seguro-v1.1.6-release-sem-servidor.apk"

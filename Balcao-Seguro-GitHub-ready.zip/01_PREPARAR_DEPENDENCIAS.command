#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

export EXPO_NO_TELEMETRY=1
LOG="01-preparar-dependencias-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee "$LOG") 2>&1

echo "============================================"
echo " Balcão Seguro — preparar dependências"
echo "============================================"
echo "Log: $LOG"

if ! command -v node >/dev/null 2>&1; then
  echo "ERRO: Node.js não encontrado. Instale com: brew install node"
  exit 1
fi

echo "== Corrigindo registry/cache do npm =="
npm config set registry https://registry.npmjs.org/
npm cache verify || true

echo "== Fixando dependências Expo 56 sem pacotes quebrados =="
node <<'NODE'
const fs = require('fs');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
pkg.dependencies = Object.assign({}, pkg.dependencies, {
  'expo': '56.0.12',
  'react': '19.2.3',
  'react-native': '0.85.3',
  '@react-native-async-storage/async-storage': '2.2.0'
});
delete pkg.dependencies['expo-splash-screen'];
delete pkg.dependencies['expo-system-ui'];
pkg.devDependencies = Object.assign({}, pkg.devDependencies, {
  '@types/react': '19.2.0',
  'typescript': '6.0.3',
  'babel-preset-expo': '56.0.15'
});
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2) + '\n');
NODE

echo "== Limpando instalação antiga =="
rm -rf node_modules package-lock.json

echo "== Instalando dependências =="
npm install --legacy-peer-deps --registry=https://registry.npmjs.org/

echo "== Conferindo TypeScript e base enriquecida =="
npx tsc --noEmit
python3 scripts/validar_base_enriquecida.py

echo ""
echo "Dependências preparadas. Próximo passo:"
echo "./02_GERAR_APK_DIRETO_ASSINADO.command"
echo "ou"
echo "./GERAR_APK_FINAL_REORGANIZADO.command"

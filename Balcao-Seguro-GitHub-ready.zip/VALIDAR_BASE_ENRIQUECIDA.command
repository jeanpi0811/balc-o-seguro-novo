#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
echo "========================================"
echo "Balcão Seguro — validar base enriquecida"
echo "========================================"
python3 scripts/validar_base_enriquecida.py

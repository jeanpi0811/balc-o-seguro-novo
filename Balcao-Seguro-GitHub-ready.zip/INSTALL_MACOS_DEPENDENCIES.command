#!/bin/bash
# Balcão Seguro — preparação completa do ambiente macOS
# Compatível com macOS Sequoia 15.7.9, Xcode 26.3 e Expo SDK 55.
# Execute a partir da raiz do projeto:
#   bash ./INSTALL_MACOS_DEPENDENCIES.command
# Para não instalar Android Studio: INSTALL_ANDROID_STUDIO=0 bash ./INSTALL_MACOS_DEPENDENCIES.command

set -euo pipefail
IFS=$'\n\t'

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_ANDROID_STUDIO="${INSTALL_ANDROID_STUDIO:-1}"

info() { printf '\033[1;34m[INFO]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[AVISO]\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31m[ERRO]\033[0m %s\n' "$*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail "Este script deve ser executado no macOS."

if [[ "$(uname -m)" == "arm64" ]]; then
  BREW_PREFIX="/opt/homebrew"
else
  BREW_PREFIX="/usr/local"
fi

if ! xcode-select -p >/dev/null 2>&1; then
  warn "As Command Line Tools do Xcode não estão instaladas. O macOS abrirá o instalador oficial."
  xcode-select --install || true
  read -r -p "Conclua a instalação das Command Line Tools e pressione Enter para continuar... " _
fi

if ! command -v brew >/dev/null 2>&1; then
  info "Instalando o Homebrew..."
  NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

if [[ -x "$BREW_PREFIX/bin/brew" ]]; then
  eval "$("$BREW_PREFIX/bin/brew" shellenv)"
elif command -v brew >/dev/null 2>&1; then
  eval "$(brew shellenv)"
else
  fail "Homebrew não foi encontrado após a instalação."
fi

info "Atualizando o Homebrew..."
brew update

info "Instalando ferramentas de desenvolvimento..."
brew install node@22 watchman cocoapods openjdk@17 jq git unzip

# O Node 22 é mantido separado pelo Homebrew; o link garante que npm/npx usem essa versão.
brew link --overwrite --force node@22 || true

# Java 17 é usado pelo Gradle/React Native/Expo no Android.
JAVA_FORMULA_PREFIX="$(brew --prefix openjdk@17)"
if [[ -d "$JAVA_FORMULA_PREFIX/libexec/openjdk.jdk/Contents/Home" ]]; then
  export JAVA_HOME="$JAVA_FORMULA_PREFIX/libexec/openjdk.jdk/Contents/Home"
else
  export JAVA_HOME="$(/usr/libexec/java_home -v 17 2>/dev/null || true)"
fi
[[ -n "${JAVA_HOME:-}" ]] || warn "JAVA_HOME não foi detectado; configure-o antes de compilar Android."

# Persistência para os shells futuros (zsh é o shell padrão do macOS).
SHELL_RC="$HOME/.zshrc"
touch "$SHELL_RC"
add_line() {
  local line="$1"
  grep -Fqx "$line" "$SHELL_RC" 2>/dev/null || printf '%s\n' "$line" >> "$SHELL_RC"
}
add_line "eval \"\$(\"$BREW_PREFIX/bin/brew\" shellenv)\""
add_line "export PATH=\"$BREW_PREFIX/opt/node@22/bin:\$PATH\""
add_line "export PATH=\"$BREW_PREFIX/opt/openjdk@17/bin:\$PATH\""
if [[ -n "${JAVA_HOME:-}" ]]; then
  add_line "export JAVA_HOME=\"$JAVA_HOME\""
fi

if [[ "$INSTALL_ANDROID_STUDIO" == "1" ]]; then
  if ! brew list --cask android-studio >/dev/null 2>&1; then
    info "Instalando Android Studio (pode demorar e ocupar vários GB)..."
    brew install --cask android-studio
  else
    info "Android Studio já está instalado."
  fi
else
  info "Android Studio ignorado (INSTALL_ANDROID_STUDIO=$INSTALL_ANDROID_STUDIO)."
fi

# Xcode precisa ser instalado pela App Store/Apple Developer e aberto manualmente uma vez.
if [[ -d "/Applications/Xcode.app" ]]; then
  info "Xcode encontrado em /Applications/Xcode.app."
  sudo xcode-select --switch /Applications/Xcode.app/Contents/Developer
  sudo xcodebuild -license accept || warn "Aceite a licença do Xcode manualmente, se solicitado."
else
  warn "Xcode não encontrado. Instale o Xcode 26.3 pela Apple antes do build iOS."
fi

info "Versões instaladas:"
node --version
npm --version
npx expo --version || true
pod --version
watchman --version || true
java -version 2>&1 | head -1 || true

if [[ -f "$PROJECT_DIR/package.json" ]]; then
  info "Instalando dependências JavaScript do projeto..."
  cd "$PROJECT_DIR"
  npm install
  npx expo install --fix

  info "Gerando/atualizando os diretórios nativos Android e iOS..."
  # Sem --clean: preserva ajustes nativos existentes e evita apagar alterações locais.
  npx expo prebuild

  info "Instalando Pods do iOS..."
  cd ios
  pod install --repo-update
  cd "$PROJECT_DIR"
else
  warn "package.json não encontrado em $PROJECT_DIR; ferramentas instaladas, mas o projeto não foi preparado."
fi

cat <<'EOF'

============================================================
Ambiente macOS preparado.

iOS:
  open ios/BalcaoSeguro.xcworkspace
  Depois, selecione o iPhone, configure Signing & Capabilities
  e execute Product > Run no Xcode.

Android:
  Abra o Android Studio uma vez para concluir o SDK/licenças.
  Depois, use:
    npx expo run:android
  ou:
    cd android && ./gradlew assembleRelease

Se este shell ainda não enxergar as variáveis persistidas, execute:
  source ~/.zshrc
============================================================
EOF

#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================"
echo " Corrigir dependências Expo 56 — Balcão Seguro"
echo "============================================"

echo "== Forçando registry oficial do npm =="
npm config set registry https://registry.npmjs.org/

echo "== Atualizando package.json para versões existentes/seguras =="
node <<'NODE'
const fs = require('fs');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
pkg.dependencies = Object.assign({}, pkg.dependencies, {
  'expo': '56.0.12',
  'react': '19.2.3',
  'react-native': '0.85.3',
  '@react-native-async-storage/async-storage': '2.2.0'
});
delete pkg.dependencies['expo-splash-screen'];
delete pkg.dependencies['expo-system-ui'];
pkg.devDependencies = Object.assign({}, pkg.devDependencies, {
  '@types/react': '19.2.0',
  'typescript': '6.0.3',
  'babel-preset-expo': '56.0.15'
});
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2) + '\n');
NODE

echo "== Limpando cache/projeto local =="
rm -rf node_modules package-lock.json android ios
npm cache clean --force || true

echo "== Instalando dependências =="
npm install --legacy-peer-deps --registry=https://registry.npmjs.org/

echo "== Teste rápido =="
npx expo --version
npx tsc --noEmit
python3 scripts/validar_base_enriquecida.py

echo ""
echo "OK. Agora rode:"
echo "./GERAR_APK_FINAL_REORGANIZADO.command"

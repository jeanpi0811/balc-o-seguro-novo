#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=================================================="
echo " Corrigir erro expo-splash-screen / expo-system-ui"
echo "=================================================="
echo "Esta versão remove os pacotes problemáticos porque o app não importa esses módulos diretamente."

node <<'NODE'
const fs = require('fs');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
if (pkg.dependencies) {
  delete pkg.dependencies['expo-splash-screen'];
  delete pkg.dependencies['expo-system-ui'];
}
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2) + '\n');
NODE

python3 <<'PY'
import json
from pathlib import Path
p=Path('app.json')
app=json.loads(p.read_text())
expo=app['expo']
expo.pop('plugins', None)
expo['splash']={'image':'./assets/splash.png','resizeMode':'contain','backgroundColor':'#0f172a'}
p.write_text(json.dumps(app,ensure_ascii=False,indent=2)+'\n')
PY

rm -rf node_modules package-lock.json android ios
npm cache clean --force || true
npm install --legacy-peer-deps --registry=https://registry.npmjs.org/
npx tsc --noEmit

echo "OK. Agora rode ./GERAR_APK_FINAL_REORGANIZADO.command"

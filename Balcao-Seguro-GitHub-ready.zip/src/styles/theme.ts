export const theme = {
  colors: {
    bg: '#0f172a',
    card: '#111827',
    card2: '#1f2937',
    text: '#f8fafc',
    muted: '#cbd5e1',
    border: '#334155',
    primary: '#38bdf8',
    green: '#22c55e',
    yellow: '#facc15',
    red: '#f87171',
    white: '#ffffff'
  },
  spacing: {
    xs: 6,
    sm: 10,
    md: 14,
    lg: 20,
    xl: 28
  },
  radius: {
    md: 14,
    lg: 20
  }
};

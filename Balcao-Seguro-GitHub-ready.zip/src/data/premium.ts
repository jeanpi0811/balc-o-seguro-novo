import { billingConfig } from './billingConfig';

export type PremiumPlan = {
  id: 'mensal' | 'anual' | 'vitalicio';
  nome: string;
  preco: string;
  recorrencia: string;
  destaque: string;
  descricao: string;
  beneficios: string[];
  productId: string;
  tipoLoja: 'assinatura' | 'compra_unica';
};

export const premiumConfig = {
  modo: 'apple_google_store_billing',
  observacao: 'Recursos digitais dentro do app devem ser vendidos pelas lojas oficiais: Apple In-App Purchase no iOS e Google Play Billing no Android. RevenueCat fica preparado como camada de integração futura.',
  suporteWhatsAppUrl: 'https://wa.me/5554991427519?text=Quero%20suporte%20do%20Balc%C3%A3o%20Seguro',
  emailSuporte: '',
  entitlementId: billingConfig.entitlementId,
  offeringId: billingConfig.offeringId,
};

export const premiumPlans: PremiumPlan[] = [
  {
    id: 'mensal',
    nome: 'Pro Mensal',
    preco: 'Definir na loja',
    recorrencia: 'assinatura mensal',
    destaque: 'Mais fácil para começar',
    descricao: 'Plano mensal vendido pela App Store no iOS e pela Play Store no Android.',
    beneficios: ['Consultas completas ilimitadas enquanto ativo', 'Renovação pela loja oficial', 'Botão restaurar compras', 'Preparado para RevenueCat', 'Sem PagSeguro para recurso digital interno'],
    productId: billingConfig.produtos.mensal,
    tipoLoja: 'assinatura',
  },
  {
    id: 'anual',
    nome: 'Pro Anual',
    preco: 'Definir na loja',
    recorrencia: 'assinatura anual',
    destaque: 'Melhor para uso contínuo',
    descricao: 'Plano anual vendido pelas lojas oficiais, ideal para rotina de balcão.',
    beneficios: ['Consultas completas ilimitadas no período', 'Menos renovações', 'Acesso às funções Pro', 'Pode ter desconto em relação ao mensal'],
    productId: billingConfig.produtos.anual,
    tipoLoja: 'assinatura',
  },
  {
    id: 'vitalicio',
    nome: 'Pro Vitalício',
    preco: 'Definir na loja',
    recorrencia: 'compra única',
    destaque: 'Compra única',
    descricao: 'Compra única não consumível pela loja oficial, para liberar acesso permanente.',
    beneficios: ['Acesso permanente no aparelho/conta da loja', 'Sem renovação mensal', 'Restaurável pela conta Apple/Google', 'Melhor para quem prefere pagar uma vez'],
    productId: billingConfig.produtos.vitalicio,
    tipoLoja: 'compra_unica',
  },
];

export type FaixaEtaria = 'nao_informada' | 'adulto' | 'crianca' | 'idoso' | 'gestante' | 'lactante';

export const faixasEtarias: { id: FaixaEtaria; label: string; descricao: string }[] = [
  { id: 'adulto', label: 'Adulto', descricao: 'Paciente adulto, sem marcador especial de idade.' },
  { id: 'crianca', label: 'Criança', descricao: 'Exige dose, forma e encaminhamento com mais cautela.' },
  { id: 'idoso', label: 'Idoso', descricao: 'Maior risco de queda, interação, sedação e efeito renal.' },
  { id: 'gestante', label: 'Gestante', descricao: 'Evitar condutas sem checagem específica para gestação.' },
  { id: 'lactante', label: 'Lactante', descricao: 'Checar segurança na amamentação antes de orientar.' }
];

export const fatoresClinicos = [
  'Alergia medicamentosa',
  'Usa anticoagulante',
  'Doença renal',
  'Doença hepática',
  'Hipertensão',
  'Diabetes',
  'Asma/DPOC',
  'Imunossupressão',
  'Polimedicado',
  'Dor intensa/febre persistente'
];

export function rotuloFaixaEtaria(id?: FaixaEtaria) {
  return faixasEtarias.find((faixa) => faixa.id === id)?.label ?? 'Não informada';
}

export const fatoresDeRisco = [
  'Gestante',
  'Lactante',
  'Criança',
  'Idoso frágil',
  'Hipertensão',
  'Diabetes',
  'Doença renal',
  'Doença hepática',
  'Uso de anticoagulante',
  'Uso de antidepressivo/sedativo',
  'Alergia medicamentosa',
  'Imunossupressão'
];

import AsyncStorage from '@react-native-async-storage/async-storage';
import { RegistroAtendimento } from '../types';

const CHAVE = '@balcao-seguro/registros';
const LIMITE_REGISTROS = 200;

export async function carregarRegistros(): Promise<RegistroAtendimento[]> {
  try {
    const bruto = await AsyncStorage.getItem(CHAVE);
    if (!bruto) return [];

    const dados = JSON.parse(bruto);
    return Array.isArray(dados) ? dados.slice(0, LIMITE_REGISTROS) : [];
  } catch {
    return [];
  }
}

export async function salvarRegistros(registros: RegistroAtendimento[]) {
  const limitados = registros.slice(0, LIMITE_REGISTROS);
  await AsyncStorage.setItem(CHAVE, JSON.stringify(limitados));
}

export async function limparRegistros() {
  await AsyncStorage.removeItem(CHAVE);
}

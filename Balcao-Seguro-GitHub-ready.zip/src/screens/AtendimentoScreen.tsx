import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ActionTile } from '../components/ActionTile';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { fatoresClinicos, faixasEtarias } from '../data/perfil';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  totalRegistros: number;
  activeScreen: ScreenName;
};

export function AtendimentoScreen({ onNavigate, totalRegistros, activeScreen }: Props) {
  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Atendimento</Title>
      <Muted>Área para iniciar o atendimento com ordem lógica: perfil → triagem → medicamento/interação → registro.</Muted>

      <PrimaryButton title="Começar novo atendimento guiado" onPress={() => onNavigate('triagem')} />

      <Card>
        <Subtitle>Antes de orientar, confirme</Subtitle>
        <View style={styles.grid}>
          {faixasEtarias.map((faixa) => <Text key={faixa.id} style={styles.pill}>{faixa.label}</Text>)}
        </View>
        <Muted>A faixa etária aparece no início da triagem e entra no registro salvo.</Muted>
      </Card>

      <Card>
        <Subtitle>Riscos que o app pergunta</Subtitle>
        <View style={styles.grid}>
          {fatoresClinicos.map((fator) => <Text key={fator} style={styles.riskPill}>{fator}</Text>)}
        </View>
      </Card>

      <ActionTile icon="📋" title="Triagem guiada" body="Perguntas objetivas para classificar sinais verdes, amarelos ou vermelhos." onPress={() => onNavigate('triagem')} tone="green" />
      <ActionTile icon="🧾" title={`Registros (${totalRegistros})`} body="Veja e compartilhe atendimentos salvos localmente no aparelho." onPress={() => onNavigate('registro')} tone="muted" />
      <ActionTile icon="🔁" title="Troca segura" body="Confira referência, genérico, similar e alertas de substituição." onPress={() => onNavigate('troca')} />

      <Card>
        <Subtitle>Regra prática</Subtitle>
        <Body>Quando houver sinal vermelho, gestação com sintoma relevante, criança pequena, idoso frágil, reação alérgica, dor intensa, febre persistente ou dúvida sobre interação, o app deve servir para organizar o encaminhamento — não para “resolver no balcão”.</Body>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8, marginBottom: 8 },
  pill: { color: theme.colors.bg, backgroundColor: theme.colors.primary, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, overflow: 'hidden', fontWeight: '900' },
  riskPill: { color: theme.colors.text, backgroundColor: theme.colors.card2, borderWidth: 1, borderColor: theme.colors.border, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, overflow: 'hidden', fontWeight: '700' }
});

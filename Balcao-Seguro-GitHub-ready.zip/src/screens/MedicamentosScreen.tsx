import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { contarStatusValidacao, corStatusValidacao, rotuloStatusValidacao } from '../data/baseMedicamentosInfo';
import { medicamentos, origemMedicamentos, totalMedicamentosEnriquecidos } from '../data/medicamentos';
import { buscarMedicamentos } from '../logic/buscaMedicamentos';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';
import { Medicamento } from '../types';
import { PremiumStatus } from '../storage/premium';

type Props = { onNavigate: (screen: ScreenName) => void; onBack?: () => void; activeScreen: ScreenName; premiumStatus: PremiumStatus };

export function MedicamentosScreen({ onNavigate, onBack, activeScreen, premiumStatus }: Props) {
  const [termo, setTermo] = useState('');
  const [selecionado, setSelecionado] = useState<string | null>(null);
  const encontrados = useMemo(() => buscarMedicamentos(medicamentos, termo).slice(0, termo.trim() ? 20 : 10), [termo]);
  const estatisticas = useMemo(() => contarStatusValidacao(medicamentos), []);
  const medicamentoSelecionado = selecionado ? medicamentos.find((item) => item.id === selecionado) : undefined;

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      {onBack ? <Pressable onPress={onBack} style={styles.backButton}><Text style={styles.backText}>‹ Voltar</Text></Pressable> : null}
      <Title>Medicamentos</Title>
      <Muted>Busca local rápida por nome, princípio ativo ou classe. Toque em um resultado para ver um resumo curto.</Muted>
      <TextInput
        value={termo}
        onChangeText={(valor) => { setTermo(valor); setSelecionado(null); }}
        placeholder="Digite: ibuprofeno, varfarina..."
        placeholderTextColor={theme.colors.muted}
        style={styles.input}
        autoCapitalize="none"
        autoCorrect={false}
        returnKeyType="search"
      />
      <Muted>{termo.trim() ? `${encontrados.length} resultado(s)` : 'Digite pelo menos parte do nome para pesquisar.'}</Muted>

      {medicamentoSelecionado ? <Resumo medicamento={medicamentoSelecionado} onFechar={() => setSelecionado(null)} /> : null}
      {termo.trim() && encontrados.map((item) => (
        <Pressable key={item.id} onPress={() => setSelecionado(item.id)} style={styles.resultado}>
          <Text style={styles.nome}>{item.nome}</Text>
          <Text style={styles.meta}>{item.principioAtivo} • {item.classe}</Text>
          <Text style={styles.abrir}>Toque para ver resumo</Text>
        </Pressable>
      ))}
      {termo.trim() && encontrados.length === 0 ? <Card><Body>Nenhum medicamento encontrado. Tente o nome do princípio ativo.</Body></Card> : null}

      <Card>
        <Subtitle>Base local</Subtitle>
        <Body>{medicamentos.length} medicamentos disponíveis para pesquisa.</Body>
        <Muted>{totalMedicamentosEnriquecidos} enriquecidos • {estatisticas.pre_validado} pré-validados • {estatisticas.parcial} parciais • {estatisticas.pendente} pendentes</Muted>
        <Muted>{origemMedicamentos}</Muted>
        <Muted>{premiumStatus.ativo ? 'Premium ativo.' : 'A pesquisa e o resumo curto são livres.'}</Muted>
      </Card>
      <PrimaryButton title="Checar interação entre dois medicamentos" onPress={() => onNavigate('interacoes')} variant="secondary" />
      <PrimaryButton title="Troca segura" onPress={() => onNavigate('troca')} variant="secondary" />
    </Screen>
  );
}

function Resumo({ medicamento, onFechar }: { medicamento: Medicamento; onFechar: () => void }) {
  const e = medicamento.enriquecimento;
  const alertas = [...(medicamento.alertas ?? []), ...(medicamento.contraindicacoes ?? []), ...(e?.alertas?.cuidados ?? [])].slice(0, 5);
  const interacoes = (e?.interacoes ?? []).slice(0, 4);
  return (
    <Card>
      <View style={styles.resumoHeader}><Subtitle>{medicamento.nome}</Subtitle><Pressable onPress={onFechar}><Text style={styles.fechar}>Fechar</Text></Pressable></View>
      <Muted>{medicamento.principioAtivo} • {medicamento.classe}</Muted>
      <Text style={[styles.status, statusStyle(corStatusValidacao(medicamento.statusValidacao))]}>{rotuloStatusValidacao(medicamento.statusValidacao)}</Text>
      <Body>{e?.resumo_leigo?.para_que_serve ?? `Forma: ${medicamento.forma}. Dosagem: ${medicamento.dosagem}.`}</Body>
      {alertas.length ? <Text style={styles.alerta}>Cuidados: {alertas.join(' • ')}</Text> : null}
      {interacoes.length ? <Text style={styles.alerta}>Interações cadastradas: {interacoes.map((item) => item.com).join(', ')}</Text> : null}
      <Muted>Resumo informativo. Confira a bula profissional do produto específico.</Muted>
    </Card>
  );
}

function statusStyle(cor: string) { return { color: cor }; }

const styles = StyleSheet.create({
  backButton: { alignSelf: 'flex-start', paddingVertical: 4, marginBottom: 8 },
  backText: { color: theme.colors.primary, fontWeight: '800', fontSize: 16 },
  input: { backgroundColor: theme.colors.card2, color: theme.colors.text, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 14, marginTop: 10, marginBottom: 8 },
  resultado: { backgroundColor: theme.colors.card, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 14, marginTop: 8 },
  nome: { color: theme.colors.text, fontSize: 17, fontWeight: '800' },
  meta: { color: theme.colors.muted, marginTop: 4 },
  abrir: { color: theme.colors.primary, marginTop: 8, fontWeight: '700' },
  resumoHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  fechar: { color: theme.colors.primary, fontWeight: '800' },
  status: { fontWeight: '800', marginVertical: 8 },
  alerta: { color: theme.colors.yellow, lineHeight: 21, marginTop: 10 },
});

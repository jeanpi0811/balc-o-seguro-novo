import React, { useEffect, useRef } from 'react';
import { Animated, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { Screen } from '../components/Screen';
import { Body, Muted } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { contarStatusValidacao } from '../data/baseMedicamentosInfo';
import { medicamentos } from '../data/medicamentos';
import { protocolos } from '../data/protocolos';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  totalRegistros: number;
  activeScreen: ScreenName;
};

export function HomeScreen({ onNavigate, totalRegistros, activeScreen }: Props) {
  const statusBase = contarStatusValidacao(medicamentos);
  const { width } = useWindowDimensions();
  const wide = width >= 720;

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <AmbientBackdrop />

      <View style={styles.topLine}>
        <View style={styles.eyebrow}><View style={styles.liveDot} /><Text style={styles.eyebrowText}>AMBIENTE LOCAL • SEGURO</Text></View>
        <Text style={styles.version}>v{appInfo.versao}</Text>
      </View>

      <BrandHero />

      <View style={styles.welcomeBlock}>
        <Text style={styles.greeting}>Bom trabalho hoje.</Text>
        <Text style={styles.pageTitle}>Como podemos ajudar?</Text>
        <Muted>Escolha um fluxo para começar com clareza e segurança.</Muted>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Acesso rápido</Text>
        <Text style={styles.sectionHint}>PRINCIPAIS FLUXOS</Text>
      </View>

      <View style={wide ? styles.actionGrid : undefined}>
        <View style={wide ? styles.actionColumn : undefined}>
          <PrimaryAction icon="+" title="Novo atendimento" body="Perfil do paciente, triagem e registro" onPress={() => onNavigate('atendimento')} />
        </View>
        <View style={wide ? styles.actionColumn : undefined}>
          <SecondaryAction icon="⌕" title="Buscar medicamento" body="Princípio ativo, alertas e contraindicações" onPress={() => onNavigate('medicamentos')} />
        </View>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Visão geral</Text>
        <Text style={styles.sectionHint}>DADOS LOCAIS</Text>
      </View>

      <Card>
        <View style={styles.statsRow}>
          <Stat label="Protocolos" value={`${protocolos.length}`} accent="blue" />
          <Stat label="Medicamentos" value={`${medicamentos.length}`} accent="green" />
          <Stat label="Registros" value={`${totalRegistros}`} accent="violet" />
        </View>
        <View style={styles.baseStatus}>
          <View style={styles.statusIcon}><Text style={styles.statusIconText}>✓</Text></View>
          <View style={styles.statusCopy}>
            <Text style={styles.statusTitle}>Base pronta para consulta</Text>
            <Text style={styles.statusBody}>{statusBase.validado} validados • {statusBase.pre_validado} pré-validados • {statusBase.pendente} pendentes</Text>
          </View>
          <View style={styles.statusBar}><View style={[styles.statusProgress, { width: `${Math.min(100, Math.max(12, (statusBase.validado / Math.max(1, medicamentos.length)) * 100))}%` }]} /></View>
        </View>
      </Card>

      <View style={wide ? styles.actionGrid : undefined}>
        <View style={wide ? styles.actionColumn : undefined}>
          <MiniAction icon="⚠" title="Interações medicamentosas" body="Checklist de orientação" onPress={() => onNavigate('interacoes')} tone="yellow" />
        </View>
        <View style={wide ? styles.actionColumn : undefined}>
          <MiniAction icon="↺" title="Ver registros" body="Histórico local de atendimentos" onPress={() => onNavigate('registro')} tone="violet" />
        </View>
      </View>

      <Card>
        <View style={styles.flowHeader}><Text style={styles.flowTitle}>Fluxo recomendado</Text><Text style={styles.flowLabel}>4 ETAPAS</Text></View>
        <View style={styles.flowRow}>
          <Step n="1" text="Identifique" /><View style={styles.flowLine} /><Step n="2" text="Triagem" /><View style={styles.flowLine} /><Step n="3" text="Consulte" /><View style={styles.flowLine} /><Step n="4" text="Registre" />
        </View>
        <Muted>Uma rotina objetiva para apoiar decisões farmacêuticas responsáveis.</Muted>
      </Card>

      <View style={styles.disclaimer}><Text style={styles.disclaimerTitle}>Apoio profissional, não substituição</Text><Text style={styles.disclaimerText}>{appInfo.responsavelFarmaceutico} — {appInfo.registroProfissional}. Não substitui julgamento farmacêutico, bula ou protocolos locais.</Text></View>
    </Screen>
  );
}

function BrandHero() {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(10)).current;
  useEffect(() => { Animated.parallel([Animated.timing(opacity, { toValue: 1, duration: 420, useNativeDriver: true }), Animated.timing(translateY, { toValue: 0, duration: 420, useNativeDriver: true })]).start(); }, [opacity, translateY]);
  return <Animated.View style={[styles.hero, { opacity, transform: [{ translateY }] }]}><View style={styles.heroCopy}><Text style={styles.brandName}>Balcão <Text style={styles.brandAccent}>Seguro</Text></Text><Text style={styles.brandTagline}>Cuidado farmacêutico com mais clareza.</Text></View><View style={styles.heroIcon}><Animated.Image source={require('../../assets/home-icon-transparent.png')} accessibilityLabel="Balcão Seguro" resizeMode="contain" style={styles.homeIcon} /></View></Animated.View>;
}

function PrimaryAction({ icon, title, body, onPress }: { icon: string; title: string; body: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.primaryAction, pressed && styles.pressed]}><View style={styles.primaryIcon}><Text style={styles.primaryIconText}>{icon}</Text></View><View style={styles.actionCopy}><Text style={styles.primaryTitle}>{title}</Text><Text style={styles.primaryBody}>{body}</Text></View><Text style={styles.actionArrow}>→</Text></Pressable>;
}

function SecondaryAction({ icon, title, body, onPress }: { icon: string; title: string; body: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.secondaryAction, pressed && styles.pressed]}><View style={styles.secondaryIcon}><Text style={styles.secondaryIconText}>{icon}</Text></View><View style={styles.actionCopy}><Text style={styles.secondaryTitle}>{title}</Text><Text style={styles.secondaryBody}>{body}</Text></View><Text style={styles.secondaryArrow}>→</Text></Pressable>;
}

function MiniAction({ icon, title, body, onPress, tone }: { icon: string; title: string; body: string; onPress: () => void; tone: 'yellow' | 'violet' }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.miniAction, pressed && styles.pressed]}><View style={[styles.miniIcon, tone === 'yellow' ? styles.yellowIcon : styles.violetIcon]}><Text style={styles.miniIconText}>{icon}</Text></View><View style={styles.actionCopy}><Text style={styles.miniTitle}>{title}</Text><Text style={styles.miniBody}>{body}</Text></View><Text style={styles.secondaryArrow}>→</Text></Pressable>;
}

function Stat({ label, value, accent }: { label: string; value: string; accent: 'blue' | 'green' | 'violet' }) { return <View style={styles.stat}><View style={[styles.statMarker, accent === 'blue' ? styles.blueMarker : accent === 'green' ? styles.greenMarker : styles.violetMarker]} /><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>; }
function Step({ n, text }: { n: string; text: string }) { return <View style={styles.step}><Text style={styles.stepBadge}>{n}</Text><Text style={styles.stepText}>{text}</Text></View>; }
function AmbientBackdrop() { return <View pointerEvents="none" style={styles.backdrop}><View style={styles.backdropOrb} /><View style={styles.backdropOrbSmall} /></View>; }

const styles = StyleSheet.create({
  backdrop: { position: 'absolute', top: -70, left: -24, right: -24, height: 360 },
  backdropOrb: { position: 'absolute', width: 300, height: 300, right: -150, top: -35, borderRadius: 150, backgroundColor: 'rgba(56, 189, 248, 0.12)', borderWidth: 1, borderColor: 'rgba(125, 211, 252, 0.18)' },
  backdropOrbSmall: { position: 'absolute', width: 170, height: 170, left: -105, top: 175, borderRadius: 100, backgroundColor: 'rgba(99, 102, 241, 0.09)', borderWidth: 1, borderColor: 'rgba(129, 140, 248, 0.14)' },
  topLine: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  eyebrow: { flexDirection: 'row', alignItems: 'center', gap: 7 }, liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#4ade80' }, eyebrowText: { color: '#93c5fd', fontSize: 9, fontWeight: '900', letterSpacing: 1.1 }, version: { color: '#64748b', fontSize: 10, fontWeight: '800' },
  hero: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 126, paddingHorizontal: 18, paddingVertical: 14, borderRadius: 24, backgroundColor: 'rgba(30, 41, 59, 0.72)', borderWidth: 1, borderColor: 'rgba(125, 211, 252, 0.24)', shadowColor: '#38bdf8', shadowOpacity: 0.16, shadowRadius: 22, shadowOffset: { width: 0, height: 10 }, elevation: 3 },
  heroCopy: { flex: 1 }, brandName: { color: '#f8fafc', fontSize: 28, fontWeight: '900', letterSpacing: -0.8 }, brandAccent: { color: '#7dd3fc' }, brandTagline: { color: '#cbd5e1', fontSize: 12, fontWeight: '600', marginTop: 8, maxWidth: 190 }, heroIcon: { width: 108, height: 108, alignItems: 'center', justifyContent: 'center' }, homeIcon: { width: 104, height: 104 },
  welcomeBlock: { marginTop: 26, marginBottom: 20 }, greeting: { color: '#7dd3fc', fontSize: 13, fontWeight: '800', marginBottom: 4 }, pageTitle: { color: '#f8fafc', fontSize: 25, fontWeight: '900', letterSpacing: -0.5, marginBottom: 5 },
  sectionHeader: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10, marginTop: 2 }, sectionTitle: { color: '#f8fafc', fontSize: 16, fontWeight: '900' }, sectionHint: { color: '#64748b', fontSize: 9, fontWeight: '900', letterSpacing: 1 },
  actionGrid: { flexDirection: 'row', gap: theme.spacing.sm }, actionColumn: { flex: 1 }, actionCopy: { flex: 1 }, pressed: { opacity: 0.72, transform: [{ scale: 0.985 }] },
  primaryAction: { flexDirection: 'row', alignItems: 'center', minHeight: 84, padding: 13, marginBottom: 18, borderRadius: 18, backgroundColor: '#0ea5e9', borderWidth: 1, borderColor: '#7dd3fc', shadowColor: '#38bdf8', shadowOpacity: 0.25, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 3 }, primaryIcon: { width: 45, height: 45, borderRadius: 15, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.18)', marginRight: 11 }, primaryIconText: { color: '#fff', fontSize: 29, fontWeight: '300', lineHeight: 33 }, primaryTitle: { color: '#fff', fontSize: 15, fontWeight: '900' }, primaryBody: { color: '#e0f2fe', fontSize: 11, lineHeight: 15, marginTop: 3 }, actionArrow: { color: '#fff', fontSize: 23, fontWeight: '300', marginLeft: 6 },
  secondaryAction: { flexDirection: 'row', alignItems: 'center', minHeight: 84, padding: 13, marginBottom: 18, borderRadius: 18, backgroundColor: 'rgba(15, 23, 42, 0.74)', borderWidth: 1, borderColor: 'rgba(125, 211, 252, 0.28)' }, secondaryIcon: { width: 45, height: 45, borderRadius: 15, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(56, 189, 248, 0.15)', marginRight: 11 }, secondaryIconText: { color: '#7dd3fc', fontSize: 30, lineHeight: 34 }, secondaryTitle: { color: '#f8fafc', fontSize: 15, fontWeight: '900' }, secondaryBody: { color: '#94a3b8', fontSize: 11, lineHeight: 15, marginTop: 3 }, secondaryArrow: { color: '#94a3b8', fontSize: 22, marginLeft: 5 },
  statsRow: { flexDirection: 'row', gap: 8, marginBottom: 14 }, stat: { flex: 1, padding: 10, borderRadius: 15, backgroundColor: 'rgba(15, 23, 42, 0.54)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.14)' }, statMarker: { width: 19, height: 3, borderRadius: 2, marginBottom: 9 }, blueMarker: { backgroundColor: '#38bdf8' }, greenMarker: { backgroundColor: '#4ade80' }, violetMarker: { backgroundColor: '#a78bfa' }, statValue: { color: '#f8fafc', fontSize: 20, fontWeight: '900' }, statLabel: { color: '#94a3b8', fontSize: 10, fontWeight: '700', marginTop: 2 },
  baseStatus: { flexDirection: 'row', alignItems: 'center', paddingTop: 13, borderTopWidth: 1, borderTopColor: 'rgba(148,163,184,0.12)' }, statusIcon: { width: 30, height: 30, borderRadius: 10, backgroundColor: 'rgba(74, 222, 128, 0.16)', alignItems: 'center', justifyContent: 'center', marginRight: 10 }, statusIconText: { color: '#4ade80', fontWeight: '900', fontSize: 15 }, statusCopy: { flex: 1 }, statusTitle: { color: '#e2e8f0', fontSize: 12, fontWeight: '900' }, statusBody: { color: '#94a3b8', fontSize: 10, marginTop: 3 }, statusBar: { width: 46, height: 5, borderRadius: 3, backgroundColor: 'rgba(148,163,184,0.18)', overflow: 'hidden', marginLeft: 8 }, statusProgress: { height: '100%', borderRadius: 3, backgroundColor: '#4ade80' },
  miniAction: { flexDirection: 'row', alignItems: 'center', minHeight: 68, padding: 11, marginBottom: 18, borderRadius: 17, backgroundColor: 'rgba(17, 24, 39, 0.74)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.18)' }, miniIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center', marginRight: 10 }, yellowIcon: { backgroundColor: 'rgba(250,204,21,0.14)' }, violetIcon: { backgroundColor: 'rgba(167,139,250,0.15)' }, miniIconText: { color: '#facc15', fontSize: 19, fontWeight: '900' }, miniTitle: { color: '#e2e8f0', fontSize: 12, fontWeight: '900' }, miniBody: { color: '#94a3b8', fontSize: 10, marginTop: 3 },
  flowHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }, flowTitle: { color: '#f8fafc', fontSize: 14, fontWeight: '900' }, flowLabel: { color: '#64748b', fontSize: 9, fontWeight: '900', letterSpacing: 1 }, flowRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 14 }, flowLine: { flex: 1, height: 1, backgroundColor: 'rgba(148,163,184,0.24)', marginTop: 11, marginHorizontal: 4 }, step: { alignItems: 'center', width: 48 }, stepBadge: { width: 23, height: 23, borderRadius: 12, backgroundColor: 'rgba(56,189,248,0.18)', borderWidth: 1, borderColor: 'rgba(125,211,252,0.38)', color: '#7dd3fc', textAlign: 'center', lineHeight: 21, fontWeight: '900', fontSize: 11 }, stepText: { color: '#94a3b8', fontSize: 9, fontWeight: '800', marginTop: 5 },
  disclaimer: { paddingHorizontal: 5, paddingBottom: 12 }, disclaimerTitle: { color: '#cbd5e1', fontSize: 11, fontWeight: '900', marginBottom: 4 }, disclaimerText: { color: '#64748b', fontSize: 10, lineHeight: 15 },
});

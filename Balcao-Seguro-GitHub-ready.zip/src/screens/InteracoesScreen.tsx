import React, { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { medicamentos } from '../data/medicamentos';
import { buscarMedicamentos } from '../logic/buscaMedicamentos';
import { avaliarInteracao } from '../logic/interacoes';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';
import { Medicamento } from '../types';
import { PremiumStatus } from '../storage/premium';

type Props = { onNavigate: (screen: ScreenName) => void; onBack?: () => void; activeScreen: ScreenName; premiumStatus: PremiumStatus; onUsarConsultaCompleta: () => Promise<boolean> };

export function InteracoesScreen({ onNavigate, onBack, activeScreen, premiumStatus, onUsarConsultaCompleta }: Props) {
  const [termoA, setTermoA] = useState('');
  const [termoB, setTermoB] = useState('');
  const [idA, setIdA] = useState<string | null>(null);
  const [idB, setIdB] = useState<string | null>(null);

  const candidatosA = useMemo(() => buscarMedicamentos(medicamentos, termoA).slice(0, 8), [termoA]);
  const candidatosB = useMemo(() => buscarMedicamentos(medicamentos, termoB).slice(0, 8), [termoB]);
  const medA = useMemo(() => idA ? medicamentos.find((item) => item.id === idA) : undefined, [idA]);
  const medB = useMemo(() => idB ? medicamentos.find((item) => item.id === idB) : undefined, [idB]);
  const resultado = medA && medB ? avaliarInteracao(medA, medB) : undefined;
  const parAtual = medA && medB ? `${medA.id}|${medB.id}` : '';
  const [parLiberado, setParLiberado] = useState('');
  const resultadoLiberado = Boolean(resultado && parAtual && parLiberado === parAtual);

  function alterarA(valor: string) {
    setTermoA(valor);
    setIdA(null);
    setParLiberado('');
  }
  function alterarB(valor: string) {
    setTermoB(valor);
    setIdB(null);
    setParLiberado('');
  }
  function selecionarA(medicamento: Medicamento) {
    setTermoA(medicamento.nome);
    setIdA(medicamento.id);
    setParLiberado('');
  }
  function selecionarB(medicamento: Medicamento) {
    setTermoB(medicamento.nome);
    setIdB(medicamento.id);
    setParLiberado('');
  }

  async function liberarResultado() {
    if (!resultado || !parAtual) return;
    const permitido = await onUsarConsultaCompleta();
    if (!permitido) {
      Alert.alert('Limite gratuito atingido', 'Você usou suas 3 consultas completas gratuitas. Assine o Premium para liberar checagens ilimitadas.', [
        { text: 'Agora não', style: 'cancel' },
        { text: 'Ver Premium', onPress: () => onNavigate('premium') },
      ]);
      return;
    }
    setParLiberado(parAtual);
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      {onBack ? <Pressable onPress={onBack} style={styles.backButton}><Text style={styles.backText}>‹ Voltar</Text></Pressable> : null}
      <Title>Interações</Title>
      <Muted>Selecione um resultado em cada campo. A checagem é didática e não substitui bula profissional nem avaliação clínica.</Muted>

      <Card>
        <Subtitle>1. Informe os dois medicamentos</Subtitle>
        <TextInput value={termoA} onChangeText={alterarA} placeholder="Medicamento 1: ex. ibuprofeno" placeholderTextColor={theme.colors.muted} style={styles.input} autoCapitalize="none" autoCorrect={false} />
        <Candidatos candidatos={candidatosA} selecionado={idA} onSelecionar={selecionarA} termo={termoA} />
        <Candidato label="Selecionado 1" medicamento={medA} termo={termoA} />

        <TextInput value={termoB} onChangeText={alterarB} placeholder="Medicamento 2: ex. varfarina" placeholderTextColor={theme.colors.muted} style={styles.input} autoCapitalize="none" autoCorrect={false} />
        <Candidatos candidatos={candidatosB} selecionado={idB} onSelecionar={selecionarB} termo={termoB} />
        <Candidato label="Selecionado 2" medicamento={medB} termo={termoB} />
      </Card>

      <Card>
        <Subtitle>Plano de uso</Subtitle>
        {premiumStatus.ativo ? <Body>Premium ativo: checagens ilimitadas neste aparelho.</Body> : <Body>Grátis: {premiumStatus.consultasUsadas}/{premiumStatus.limiteGratis} consultas completas usadas. Restam {premiumStatus.consultasRestantes}.</Body>}
        <Muted>Pesquisar e selecionar são livres. Ver o resultado completo consome 1 consulta gratuita.</Muted>
        {!premiumStatus.ativo && premiumStatus.consultasRestantes === 0 ? <PrimaryButton title="Assinar Premium" onPress={() => onNavigate('premium')} variant="success" /> : null}
      </Card>

      {medA && medB && resultado && !resultadoLiberado && (
        <Card>
          <Subtitle>Resultado pronto</Subtitle>
          <Body>Os dois medicamentos foram selecionados. Toque abaixo para liberar a checagem completa.</Body>
          <PrimaryButton title="Ver checagem completa" onPress={liberarResultado} variant="primary" />
        </Card>
      )}

      {resultado && resultadoLiberado && <Card><Text style={[styles.badge, styles[resultado.nivel]]}>{rotuloNivel(resultado.nivel)}</Text><Subtitle>{resultado.titulo}</Subtitle><Section title="Alertas encontrados" items={resultado.alertas} /><Section title="Checklist obrigatório" items={resultado.checklist} /></Card>}
      {(!medA || !medB) && <Card><Body>Digite e toque em um medicamento da lista de resultados para preencher os dois campos.</Body></Card>}
    </Screen>
  );
}

function Candidatos({ candidatos, selecionado, onSelecionar, termo }: { candidatos: Medicamento[]; selecionado: string | null; onSelecionar: (medicamento: Medicamento) => void; termo: string }) {
  if (!termo.trim() || selecionado || candidatos.length === 0) return termo.trim() && !selecionado && candidatos.length === 0 ? <Text style={styles.notFound}>Nenhum medicamento encontrado na base local.</Text> : null;
  return <View style={styles.candidates}><Muted>Toque para selecionar:</Muted>{candidatos.map((item) => <Pressable key={item.id} onPress={() => onSelecionar(item)} style={styles.candidate}><Text style={styles.candidateName}>{item.nome}</Text><Text style={styles.candidateMeta}>{item.principioAtivo} • {item.classe}</Text></Pressable>)}</View>;
}

function Candidato({ label, medicamento, termo }: { label: string; medicamento?: Medicamento; termo: string }) {
  if (!termo.trim()) return <Muted>{label}: aguardando busca.</Muted>;
  if (!medicamento) return <Muted>{label}: selecione um resultado acima.</Muted>;
  return <Text style={styles.selected}>{label}: {medicamento.nome} • {medicamento.principioAtivo}</Text>;
}

function Section({ title, items }: { title: string; items: string[] }) { return <View style={styles.section}><Text style={styles.sectionTitle}>{title}</Text>{items.map((item, index) => <Text key={`${title}-${index}`} style={styles.item}>• {item}</Text>)}</View>; }
function rotuloNivel(nivel: 'baixo' | 'atencao' | 'alto') { if (nivel === 'alto') return 'RISCO/ATENÇÃO ALTA'; if (nivel === 'atencao') return 'ATENÇÃO'; return 'BAIXO NA CHECAGEM INICIAL'; }

const styles = StyleSheet.create({
  backButton: { alignSelf: 'flex-start', paddingVertical: 4, paddingHorizontal: 2, marginBottom: 8 },
  backText: { color: theme.colors.primary, fontWeight: '800', fontSize: 16 },
  input: { backgroundColor: theme.colors.card2, color: theme.colors.text, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 14, marginTop: 10, marginBottom: 8 },
  candidates: { marginBottom: 8 },
  candidate: { backgroundColor: theme.colors.card2, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 10, marginTop: 6 },
  candidateName: { color: theme.colors.text, fontWeight: '800' },
  candidateMeta: { color: theme.colors.muted, marginTop: 2, fontSize: 12 },
  selected: { color: theme.colors.green, fontWeight: '800', lineHeight: 20 },
  notFound: { color: theme.colors.red, lineHeight: 20 },
  badge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, overflow: 'hidden', color: theme.colors.bg, fontWeight: '900', marginBottom: 8 },
  baixo: { backgroundColor: theme.colors.green }, atencao: { backgroundColor: theme.colors.yellow }, alto: { backgroundColor: theme.colors.red },
  section: { marginTop: 12 }, sectionTitle: { color: theme.colors.text, fontWeight: '800', marginBottom: 4 }, item: { color: theme.colors.muted, lineHeight: 20 }
});

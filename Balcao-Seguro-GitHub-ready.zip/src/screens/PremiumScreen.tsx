import React, { useState } from 'react';
import { Alert, Linking, StyleSheet, Text, TextInput, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { billingConfig } from '../data/billingConfig';
import { premiumConfig, premiumPlans, PremiumPlan } from '../data/premium';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';
import { PremiumState, PremiumStatus } from '../storage/premium';

type Props = { onNavigate: (screen: ScreenName) => void; activeScreen: ScreenName; premiumStatus: PremiumStatus; onAtivarCodigo: (codigo: string) => Promise<{ ok: boolean; estado: PremiumState; mensagem: string }>; recursoBloqueado?: ScreenName };

export function PremiumScreen({ onNavigate, activeScreen, premiumStatus, onAtivarCodigo, recursoBloqueado }: Props) {
  const [codigo, setCodigo] = useState('');

  async function abrirPlano(plano: PremiumPlan) {
    Alert.alert(
      'Compra oficial preparada',
      `Este plano usará a compra oficial da loja.\n\nProduto: ${plano.productId}\nTipo: ${plano.tipoLoja === 'assinatura' ? 'assinatura' : 'compra única'}\n\nPróximo passo: criar esse produto no App Store Connect, Google Play Console e RevenueCat.`,
      [
        { text: 'OK' },
        { text: 'Abrir Área Dev', onPress: () => onNavigate('dev') },
      ]
    );
  }

  async function restaurarCompras() {
    Alert.alert(
      'Restaurar compras',
      'O botão já está posicionado. A restauração real será conectada quando o SDK RevenueCat/react-native-purchases for ativado com as chaves públicas do projeto.'
    );
  }

  async function abrirSuporte() {
    await Linking.openURL(premiumConfig.suporteWhatsAppUrl);
  }

  async function ativarCodigo() {
    const resultado = await onAtivarCodigo(codigo);
    Alert.alert(resultado.ok ? 'Acesso ativado' : 'Código inválido', resultado.mensagem);
    if (resultado.ok) setCodigo('');
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Balcão Seguro Pro</Title>
      <Muted>{recursoBloqueado ? 'Este recurso faz parte do Balcão Seguro Pro.' : 'Preparado para assinatura oficial da App Store no iOS e Google Play Billing no Android.'}</Muted>

      <Card>
        <Text style={styles.heroBadge}>💎 Pro profissional</Text>
        <Subtitle>Mais segurança e produtividade no balcão</Subtitle>
        <Body>Desbloqueie recursos avançados para atendimento farmacêutico, histórico local, análise de interações, exportação de dados e ferramentas administrativas.</Body>
        <Muted>Em breve disponível para assinatura. Nesta versão demonstrativa, a Área Admin pode liberar o Pro localmente.</Muted>
        <Muted>Entitlement: {billingConfig.entitlementId} · Offering: {billingConfig.offeringId}</Muted>
      </Card>

      <Card>
        <Subtitle>Status do acesso</Subtitle>
        {premiumStatus.ativo ? (
          <Body>💎 Pro ativo. Consultas completas ilimitadas neste aparelho.</Body>
        ) : (
          <Body>Grátis: {premiumStatus.consultasUsadas}/{premiumStatus.limiteGratis} consultas completas usadas. Restam {premiumStatus.consultasRestantes}.</Body>
        )}
        <Muted>A busca básica continua livre. O limite vale para abrir resultados completos de medicamentos e interações.</Muted>
      </Card>

      {premiumPlans.map((plano) => <PlanCard key={plano.id} plano={plano} onPress={() => abrirPlano(plano)} />)}

      <Card>
        <Subtitle>Restaurar compras</Subtitle>
        <Body>Quando a integração RevenueCat estiver conectada, este botão restaurará compras feitas pela conta Apple/Google do usuário.</Body>
        <PrimaryButton title="Restaurar compra" onPress={restaurarCompras} variant="secondary" />
        <PrimaryButton title="Voltar" onPress={() => onNavigate('home')} variant="secondary" />
      </Card>

      <Card>
        <Subtitle>O que pode entrar no Pro</Subtitle>
        <Bullet text="Base ampliada e atualizações de substâncias." />
        <Bullet text="Filtros profissionais por grupo de risco: idoso, gestante, renal, hepático, anticoagulante e diabetes." />
        <Bullet text="Interações com alerta mais claro e checklist de orientação." />
        <Bullet text="Exportação/relatório de atendimento em versão futura." />
        <Bullet text="Prioridade para inclusão de novos medicamentos solicitados pelo usuário." />
      </Card>

      <Card>
        <Subtitle>Liberação local de teste</Subtitle>
        <Body>Enquanto as lojas não estiverem configuradas, você pode usar código local somente para teste/dev.</Body>
        <TextInput value={codigo} onChangeText={setCodigo} placeholder="Código de teste" placeholderTextColor={theme.colors.muted} style={styles.input} autoCapitalize="characters" autoCorrect={false} />
        <PrimaryButton title="Ativar código local" onPress={ativarCodigo} variant="success" />
        <Muted>Para publicação final, a liberação real deve vir da App Store/Google Play/RevenueCat, não de código manual.</Muted>
      </Card>

      <Card>
        <Subtitle>Suporte</Subtitle>
        <Body>Use o WhatsApp para dúvidas, atendimento humano ou suporte fora da compra digital do app.</Body>
        <Muted>Serviços humanos individuais podem ter tratamento diferente, mas recursos digitais internos devem seguir as lojas oficiais.</Muted>
        <PrimaryButton title="Falar no WhatsApp" onPress={abrirSuporte} variant="secondary" />
      </Card>
    </Screen>
  );
}

function PlanCard({ plano, onPress }: { plano: PremiumPlan; onPress: () => void }) {
  const destaque = plano.id === 'anual';
  return (
    <Card>
      <View style={styles.planHeader}>
        <View style={{ flex: 1 }}>
          <Text style={styles.planTag}>{plano.destaque}</Text>
          <Subtitle>{plano.nome}</Subtitle>
        </View>
        <View style={[styles.priceBox, destaque && styles.priceBoxHighlight]}>
          <Text style={styles.price}>{plano.preco}</Text>
          <Text style={styles.recurrence}>{plano.recorrencia}</Text>
        </View>
      </View>
      <Body>{plano.descricao}</Body>
      <Text style={styles.productId}>ID: {plano.productId}</Text>
      <View style={styles.benefits}>
        {plano.beneficios.map((beneficio) => <Bullet key={beneficio} text={beneficio} />)}
      </View>
      <PrimaryButton title={`Ver plano ${plano.nome}`} onPress={onPress} variant={destaque ? 'success' : 'primary'} />
    </Card>
  );
}

function Bullet({ text }: { text: string }) {
  return <Text style={styles.bullet}>• {text}</Text>;
}

const styles = StyleSheet.create({
  heroBadge: { color: theme.colors.yellow, fontWeight: '900', marginBottom: 8 },
  planHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, marginBottom: 8 },
  planTag: { color: theme.colors.primary, fontWeight: '900', fontSize: 12, marginBottom: 4 },
  priceBox: { backgroundColor: theme.colors.card2, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 10, minWidth: 108, alignItems: 'center' },
  priceBoxHighlight: { borderColor: theme.colors.green },
  price: { color: theme.colors.text, fontSize: 14, fontWeight: '900', textAlign: 'center' },
  recurrence: { color: theme.colors.muted, fontSize: 10, marginTop: 2, textAlign: 'center' },
  productId: { color: theme.colors.primary, fontWeight: '800', marginTop: 8, fontSize: 12 },
  benefits: { marginTop: 8, marginBottom: 8 },
  bullet: { color: theme.colors.muted, lineHeight: 20, marginBottom: 4 },
  input: { backgroundColor: theme.colors.card2, color: theme.colors.text, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 14, marginTop: 10, marginBottom: 8 },
});

import { ProtocoloTriagem, RespostaTriagem, ResultadoTriagem } from '../types';

export function avaliarTriagem(protocolo: ProtocoloTriagem, respostas: RespostaTriagem): ResultadoTriagem {
  const perguntasMarcadas = protocolo.perguntas.filter((pergunta) => respostas[pergunta.id]);
  const vermelhas = perguntasMarcadas.filter((pergunta) => pergunta.gravidade === 'vermelho');
  const amarelas = perguntasMarcadas.filter((pergunta) => pergunta.gravidade === 'amarelo');

  if (vermelhas.length > 0) {
    return {
      gravidade: 'vermelho',
      titulo: 'Encaminhar / não resolver apenas no balcão',
      motivos: vermelhas.map((pergunta) => pergunta.motivo),
      condutas: protocolo.condutaVermelha,
      mipPossiveis: [],
      evitar: protocolo.evitar
    };
  }

  if (amarelas.length > 0) {
    return {
      gravidade: 'amarelo',
      titulo: 'Atenção: exige avaliação farmacêutica completa',
      motivos: amarelas.map((pergunta) => pergunta.motivo),
      condutas: protocolo.orientacaoAmarela,
      mipPossiveis: protocolo.mipPossiveis,
      evitar: protocolo.evitar
    };
  }

  return {
    gravidade: 'verde',
    titulo: 'Baixo risco aparente na triagem inicial',
    motivos: ['Nenhum sinal crítico marcado nas perguntas desta triagem.'],
    condutas: protocolo.orientacaoVerde,
    mipPossiveis: protocolo.mipPossiveis,
    evitar: protocolo.evitar
  };
}

export function textoGravidade(gravidade: ResultadoTriagem['gravidade']) {
  if (gravidade === 'vermelho') return 'Vermelho';
  if (gravidade === 'amarelo') return 'Amarelo';
  return 'Verde';
}

import { Medicamento } from '../types';

function normalizar(valor: unknown): string {
  return String(valor ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}

const indiceProfundo = new WeakMap<Medicamento, string>();

function camposBasicos(medicamento: Medicamento): string[] {
  return [
    medicamento.nome,
    medicamento.principioAtivo,
    medicamento.classe,
    medicamento.tarja,
    medicamento.forma,
    medicamento.dosagem,
    medicamento.referencia ?? '',
    medicamento.numeroRegistroAnvisa ?? '',
    medicamento.situacaoRegistro ?? '',
    medicamento.categoriaRegulatoria ?? '',
    medicamento.detentorRegistro ?? '',
    medicamento.statusValidacao ?? '',
    medicamento.escopoValidacao ?? '',
    medicamento.revisaoVenceEm ?? '',
    ...(medicamento.genericos ?? []),
    ...(medicamento.similaresIntercambiaveis ?? []),
  ];
}

function camposProfundos(medicamento: Medicamento): string[] {
  const e = medicamento.enriquecimento;
  if (!e) return [];
  return [
    e.uso_orientativo?.para_que_serve,
    e.uso_orientativo?.indicacao_geral,
    e.resumo_leigo?.para_que_serve,
    e.resumo_leigo?.quando_ter_cuidado,
    e.resumo_leigo?.quando_procurar_atendimento,
    e.resumo_leigo?.o_que_nao_fazer,
    ...(e.formas ?? []),
    ...(e.vias ?? []),
    ...(e.concentracoes ?? []),
    ...(e.alertas?.contraindicacoes ?? []),
    ...(e.alertas?.cuidados ?? []),
    ...(e.alertas?.sinais_alerta ?? []),
    ...(e.alertas?.quando_encaminhar ?? []),
    ...(e.triagem_farmaceutica?.perguntas_obrigatorias ?? []),
    ...(e.triagem_farmaceutica?.perguntas_recomendadas ?? []),
    ...(e.interacoes ?? []).flatMap((i) => [i.com, i.classe_ou_medicamento, i.gravidade, i.consequencia]),
    ...Object.entries(e.grupos_especiais ?? {}).flatMap(([chave, valor]) => [chave, valor?.classificacao, valor?.observacao]),
    ...(e.fontes ?? []).flatMap((fonte) => [fonte.nome, fonte.resumo_usado, fonte.nivel_confianca]),
    ...(e.status_validacao?.pendencias ?? []),
    e.status_validacao?.observacoes,
    e.aviso_responsabilidade,
  ];
}

function textoProfundo(medicamento: Medicamento): string {
  const existente = indiceProfundo.get(medicamento);
  if (existente) return existente;
  const texto = normalizar([...camposBasicos(medicamento), ...camposProfundos(medicamento)].join(' '));
  indiceProfundo.set(medicamento, texto);
  return texto;
}

function pontuacaoBusca(medicamento: Medicamento, q: string): number {
  const nome = normalizar(medicamento.nome);
  const principio = normalizar(medicamento.principioAtivo);
  if (nome === q || principio === q) return 1000;
  if (nome.startsWith(q) || principio.startsWith(q)) return 800;
  if (nome.includes(q) || principio.includes(q)) return 600;
  if (normalizar(medicamento.classe).includes(q)) return 400;
  return 100;
}

function ordenar(resultados: Medicamento[], q: string): Medicamento[] {
  return resultados.sort((a, b) => pontuacaoBusca(b, q) - pontuacaoBusca(a, q));
}

export function buscarMedicamentos(medicamentos: Medicamento[], termo: string): Medicamento[] {
  const q = normalizar(termo);
  if (!q) return medicamentos;

  // Caminho rápido: não percorre o JSON enriquecido a cada tecla.
  const basicos = medicamentos.filter((medicamento) => camposBasicos(medicamento).some((campo) => normalizar(campo).includes(q)));
  if (basicos.length > 0) return ordenar(basicos, q);

  // Só consulta o índice clínico profundo quando não há resultado básico.
  if (q.length < 3) return [];
  return ordenar(medicamentos.filter((medicamento) => textoProfundo(medicamento).includes(q)), q);
}

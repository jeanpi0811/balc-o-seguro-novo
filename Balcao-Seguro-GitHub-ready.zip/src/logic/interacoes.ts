import { InteracaoMedicamentoEnriquecida, Medicamento } from '../types';

export type ResultadoInteracao = {
  nivel: 'baixo' | 'atencao' | 'alto';
  titulo: string;
  alertas: string[];
  checklist: string[];
  interacoesEncontradas: InteracaoMedicamentoEnriquecida[];
};

function normalizar(valor: string) {
  return valor.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
}

function textoMed(med: Medicamento) {
  const e = med.enriquecimento;
  return [
    med.nome,
    med.principioAtivo,
    med.classe,
    med.tarja,
    ...(med.alertas ?? []),
    ...(med.contraindicacoes ?? []),
    ...(med.perguntasChave ?? []),
    ...(med.quandoEncaminhar ?? []),
    ...(e ? [
      e.classe_terapeutica,
      e.tarja,
      e.tipo_venda,
      ...e.alertas.cuidados,
      ...e.alertas.contraindicacoes,
      ...Object.values(e.grupos_especiais).flatMap((g) => [g.classificacao, g.observacao]),
      ...e.interacoes.flatMap((i) => [i.com, i.classe_ou_medicamento, i.gravidade, i.consequencia])
    ] : [])
  ].join(' ').toLowerCase();
}

function contem(med: Medicamento, termos: string[]) {
  const texto = textoMed(med);
  return termos.some((termo) => texto.includes(termo.toLowerCase()));
}

function tokensAlvo(interacao: InteracaoMedicamentoEnriquecida): string[] {
  const bruto = `${interacao.com} ${interacao.classe_ou_medicamento}`;
  return normalizar(bruto)
    .split(/[,;/]|\se\s|\sou\s|\s\+\s/g)
    .map((t) => t.trim())
    .filter((t) => t.length >= 4 && t !== 'medicamentos' && t !== 'classe' && t !== 'outros');
}

function interacoesDiretas(origem: Medicamento, alvo: Medicamento): InteracaoMedicamentoEnriquecida[] {
  const alvoTexto = normalizar(textoMed(alvo));
  const interacoes = origem.enriquecimento?.interacoes ?? [];
  return interacoes.filter((interacao) => tokensAlvo(interacao).some((token) => alvoTexto.includes(token)));
}

function nivelPorGravidade(interacoes: InteracaoMedicamentoEnriquecida[]) {
  if (interacoes.some((i) => i.gravidade === 'grave' || i.gravidade === 'contraindicada')) return 'alto' as const;
  if (interacoes.some((i) => i.gravidade === 'moderada')) return 'atencao' as const;
  return 'baixo' as const;
}

export function avaliarInteracao(a: Medicamento, b: Medicamento): ResultadoInteracao {
  const alertas: string[] = [];
  const checklist = [
    'Confirmar princípio ativo, dose, via, frequência e duração de uso.',
    'Perguntar alergias, gestação/lactação, idade, rim/fígado, anticoagulantes e medicamentos contínuos.',
    'Conferir bula profissional e fonte oficial quando a base estiver parcial ou pendente.',
    'Registrar orientação e encaminhar se houver sinal de alerta.'
  ];

  const encontradas = [...interacoesDiretas(a, b), ...interacoesDiretas(b, a)];
  encontradas.forEach((i) => alertas.push(`${i.gravidade.toUpperCase()} — ${i.com}: ${i.consequencia} Orientação: ${i.orientacao_segura}`));

  if (a.principioAtivo.toLowerCase() === b.principioAtivo.toLowerCase()) {
    alertas.push('Possível duplicidade: os dois itens têm o mesmo princípio ativo. Risco de dose duplicada.');
  }

  const aAINE = contem(a, ['anti-inflamat', 'ibuprofeno', 'diclofenaco', 'naproxeno', 'nimesulida', 'cetoprofeno']);
  const bAINE = contem(b, ['anti-inflamat', 'ibuprofeno', 'diclofenaco', 'naproxeno', 'nimesulida', 'cetoprofeno']);
  const aAnticoag = contem(a, ['anticoagulante', 'varfarina', 'rivaroxabana', 'apixabana', 'dabigatrana', 'heparina', 'clopidogrel']);
  const bAnticoag = contem(b, ['anticoagulante', 'varfarina', 'rivaroxabana', 'apixabana', 'dabigatrana', 'heparina', 'clopidogrel']);
  if ((aAINE && bAnticoag) || (bAINE && aAnticoag)) alertas.push('AINE + anticoagulante/antiagregante/risco de sangramento: exige conferência e geralmente cautela importante.');
  if (aAINE && bAINE) alertas.push('Dois anti-inflamatórios juntos: risco aumentado de eventos gástricos, renais e cardiovasculares.');

  const aSed = contem(a, ['sedativo', 'benzodiazep', 'sonolência', 'sono', 'depressão do sistema nervoso', 'opioide', 'anti-histamínico h1 de primeira']);
  const bSed = contem(b, ['sedativo', 'benzodiazep', 'sonolência', 'sono', 'depressão do sistema nervoso', 'opioide', 'anti-histamínico h1 de primeira']);
  if (aSed && bSed) alertas.push('Possível soma de sedação/sonolência: orientar cautela com direção, quedas, álcool e idosos.');

  const aQT = contem(a, ['qt', 'arritmia', 'macrolídeo', 'ondansetrona', 'azitromicina']);
  const bQT = contem(b, ['qt', 'arritmia', 'macrolídeo', 'ondansetrona', 'azitromicina']);
  if (aQT && bQT) alertas.push('Possível soma de risco de QT/arritmia: conferir bula, eletrólitos, cardiopatia e medicamentos em uso.');

  const aSer = contem(a, ['serotonina', 'serotoninérgico', 'ssri', 'isrs', 'triptano']);
  const bSer = contem(b, ['serotonina', 'serotoninérgico', 'ssri', 'isrs', 'triptano']);
  if (aSer && bSer) alertas.push('Possível soma serotoninérgica: conferir bula e sintomas de alerta, especialmente se houver antidepressivos/triptanos.');

  if (a.tarja === 'Tarja preta' || b.tarja === 'Tarja preta' || a.tarja === 'Controle especial' || b.tarja === 'Controle especial') {
    alertas.push('Há medicamento de controle especial/tarja preta: conferir prescrição, legislação, sedação e duplicidades.');
  }

  if (contem(a, ['renal', 'rim']) || contem(b, ['renal', 'rim'])) checklist.push('Se houver doença renal, evitar assumir dose usual sem conferência.');
  if (contem(a, ['hepátic', 'fígado', 'figado']) || contem(b, ['hepátic', 'fígado', 'figado'])) checklist.push('Se houver doença hepática, revisar risco e dose antes de orientar.');
  if (contem(a, ['gesta', 'lacta', 'amament']) || contem(b, ['gesta', 'lacta', 'amament'])) checklist.push('Gestação/lactação: não orientar sem checagem específica para o produto.');

  const nivelPorBase = nivelPorGravidade(encontradas);
  if (nivelPorBase === 'alto' || alertas.length >= 2 || alertas.some((a) => a.includes('duplicidade') || a.includes('sangramento') || a.includes('anti-inflamatórios') || a.includes('QT'))) {
    return { nivel: 'alto', titulo: 'Atenção alta: conferir antes de orientar', alertas, checklist, interacoesEncontradas: encontradas };
  }

  if (nivelPorBase === 'atencao' || alertas.length === 1) return { nivel: 'atencao', titulo: 'Atenção: há ponto de checagem', alertas, checklist, interacoesEncontradas: encontradas };

  return {
    nivel: 'baixo',
    titulo: 'Nenhuma interação crítica detectada nesta checagem inicial',
    alertas: ['A ausência de alerta aqui não garante ausência de interação. Esta versão usa triagem local e deve ser conferida em bula/fonte oficial.'],
    checklist,
    interacoesEncontradas: encontradas
  };
}

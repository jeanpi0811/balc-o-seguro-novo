import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { AppTab, ScreenName } from '../navigation';
import { theme } from '../styles/theme';

type Props = {
  active: AppTab;
  onNavigate: (screen: ScreenName) => void;
};

const tabs: { id: AppTab; screen: ScreenName; label: string; icon: string }[] = [
  { id: 'home', screen: 'home', label: 'Início', icon: '⌂' },
  { id: 'atendimento', screen: 'atendimento', label: 'Atendimento', icon: '🎧' },
  { id: 'medicamentos', screen: 'medicamentos', label: 'Medicamentos', icon: '💊' },
  { id: 'interacoes', screen: 'interacoes', label: 'Interações', icon: '⚠️' },
  { id: 'mais', screen: 'mais', label: 'Mais', icon: '•••' },
];

export function BottomTabs({ active, onNavigate }: Props) {
  return (
    <View style={styles.wrap}>
      {tabs.map((tab) => {
        const selected = tab.id === active;
        return (
          <Pressable key={tab.id} onPress={() => onNavigate(tab.screen)} style={({ pressed }) => [styles.item, selected && styles.selected, pressed && styles.pressed]}>
            <Text style={[styles.icon, selected && styles.selectedText]}>{tab.icon}</Text>
            <Text style={[styles.label, selected && styles.selectedText]} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.58}>{tab.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    backgroundColor: 'rgba(17, 24, 39, 0.92)',
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(148, 163, 184, 0.24)',
    padding: 4
  },
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 8, borderRadius: 18 },
  selected: { backgroundColor: 'rgba(56, 189, 248, 0.18)', borderWidth: 1, borderColor: 'rgba(56, 189, 248, 0.40)' },
  pressed: { opacity: 0.7 },
  icon: { color: theme.colors.muted, fontWeight: '900', fontSize: 15, lineHeight: 18 },
  label: { color: theme.colors.muted, fontSize: 9, fontWeight: '800', marginTop: 2, width: '100%', textAlign: 'center' },
  selectedText: { color: theme.colors.primary }
});

import React from 'react';
import { Image, StyleSheet, View } from 'react-native';
import { Muted, Title } from './TextBits';
import { theme } from '../styles/theme';

export function Header({ title = 'Balcão Seguro', subtitle }: { title?: string; subtitle?: string }) {
  return (
    <View style={styles.header}>
      <Image source={require('../../assets/home-icon-transparent.png')} resizeMode="contain" style={styles.logo} />
      <View style={styles.headerText}>
        <Title>{title}</Title>
        {subtitle ? <Muted>{subtitle}</Muted> : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', gap: theme.spacing.md, marginBottom: theme.spacing.md },
  logo: { width: 68, height: 68, borderRadius: 18 },
  headerText: { flex: 1 }
});

import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { theme } from '../styles/theme';

type Props = {
  icon: string;
  title: string;
  body: string;
  onPress: () => void;
  tone?: 'primary' | 'green' | 'yellow' | 'red' | 'muted';
};

export function ActionTile({ icon, title, body, onPress, tone = 'primary' }: Props) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
      <View style={[styles.iconBox, toneStyles[tone]]}><Text style={styles.icon}>{icon}</Text></View>
      <View style={styles.textBox}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.body}>{body}</Text>
      </View>
      <Text style={styles.chevron}>›</Text>
    </Pressable>
  );
}

const toneStyles = StyleSheet.create({
  primary: { backgroundColor: 'rgba(56, 189, 248, 0.16)', borderColor: 'rgba(56, 189, 248, 0.28)' },
  green: { backgroundColor: 'rgba(34, 197, 94, 0.16)', borderColor: 'rgba(34, 197, 94, 0.28)' },
  yellow: { backgroundColor: 'rgba(250, 204, 21, 0.16)', borderColor: 'rgba(250, 204, 21, 0.28)' },
  red: { backgroundColor: 'rgba(248, 113, 113, 0.16)', borderColor: 'rgba(248, 113, 113, 0.28)' },
  muted: { backgroundColor: 'rgba(203, 213, 225, 0.10)', borderColor: 'rgba(203, 213, 225, 0.16)' }
});

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(17, 24, 39, 0.76)',
    borderWidth: 1,
    borderColor: 'rgba(148, 163, 184, 0.24)',
    borderRadius: theme.radius.lg,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    shadowColor: '#38bdf8',
    shadowOpacity: 0.08,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 8 },
    elevation: 2
  },
  pressed: { opacity: 0.75 },
  iconBox: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginRight: 12, borderWidth: 1 },
  icon: { fontSize: 23 },
  textBox: { flex: 1 },
  title: { color: theme.colors.text, fontWeight: '900', fontSize: 16, marginBottom: 4 },
  body: { color: theme.colors.muted, fontSize: 13, lineHeight: 18 },
  chevron: { color: theme.colors.muted, fontSize: 30, fontWeight: '300', marginLeft: 8 }
});

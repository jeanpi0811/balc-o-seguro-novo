#!/bin/bash
set -e
cd "$(dirname "$0")"

clear
echo "======================================================"
echo " Balcão Seguro v1.2.2 — preparar macOS para iOS/Xcode"
echo "======================================================"
echo ""

if [[ "$(uname)" != "Darwin" ]]; then
  echo "ERRO: este preparo iOS só funciona no macOS."
  exit 1
fi

echo "== Verificando Xcode =="
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERRO: xcodebuild não encontrado."
  echo "Instale o Xcode pela App Store ou pelo Apple Developer."
  exit 1
fi

xcodebuild -version || true

echo ""
echo "== Selecionando Xcode.app se existir =="
if [ -d "/Applications/Xcode.app" ]; then
  sudo xcode-select -s /Applications/Xcode.app/Contents/Developer || true
fi

echo ""
echo "== Aceitando licença do Xcode se necessário =="
sudo xcodebuild -license accept || true

echo ""
echo "== Verificando Node.js =="
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js não encontrado."
  if command -v brew >/dev/null 2>&1; then
    echo "Homebrew encontrado. Instalando node..."
    brew install node
  else
    echo "Instale Homebrew ou Node.js manualmente."
    echo "Homebrew: https://brew.sh"
    exit 1
  fi
fi

node -v
npm -v

echo ""
echo "== Verificando CocoaPods =="
if ! command -v pod >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then
    echo "Instalando CocoaPods via Homebrew..."
    brew install cocoapods
  else
    echo "Homebrew não encontrado. Tentando instalar CocoaPods via gem..."
    sudo gem install cocoapods
  fi
fi

pod --version || true

echo ""
echo "== Instalando dependências do projeto =="
rm -rf node_modules
rm -f package-lock.json npm-shrinkwrap.json
npm config set registry https://registry.npmjs.org/
npm cache clean --force || true
npm install --legacy-peer-deps --no-audit --fund=false

echo ""
echo "Pronto. Agora rode:"
echo "./01_GERAR_IOS_ABRIR_XCODE.command"

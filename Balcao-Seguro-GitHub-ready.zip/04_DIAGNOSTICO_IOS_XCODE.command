#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "===================================================="
echo " Diagnóstico iOS/Xcode — Balcão Seguro"
echo "===================================================="
echo ""

echo "macOS:"
sw_vers || true
echo ""

echo "Xcode:"
xcodebuild -version || true
xcode-select -p || true
echo ""

echo "Node/npm:"
node -v || true
npm -v || true
echo ""

echo "CocoaPods:"
pod --version || true
echo ""

echo "Dispositivos visíveis para Xcode:"
xcrun xctrace list devices 2>/dev/null || xcrun instruments -s devices 2>/dev/null || true
echo ""

echo "Arquivos principais:"
ls -la app.json package.json App.tsx 2>/dev/null || true

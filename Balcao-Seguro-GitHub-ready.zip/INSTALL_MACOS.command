#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "== Balcão Seguro: instalando dependências =="

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js não encontrado. Instale pelo site oficial ou via Homebrew: brew install node"
  exit 1
fi

npm install
npx expo install --fix || true

echo ""
echo "Instalação concluída. Para abrir o app:"
echo "./RODAR_MACOS.command"

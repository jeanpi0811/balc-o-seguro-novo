#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -d "ios" ]; then
  echo "A pasta ios/ ainda não existe. Rode:"
  echo "./01_GERAR_IOS_ABRIR_XCODE.command"
  exit 1
fi

if command -v xed >/dev/null 2>&1; then
  xed ios
else
  open ios/*.xcworkspace 2>/dev/null || open ios
fi

#!/bin/bash
set -e
cd "$(dirname "$0")"

clear
echo "=========================================================="
echo " Balcão Seguro v1.2.2 — gerar iOS e abrir no Xcode"
echo "=========================================================="
echo ""

if [[ "$(uname)" != "Darwin" ]]; then
  echo "ERRO: iOS/Xcode só funciona no macOS."
  exit 1
fi

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERRO: Xcode não encontrado."
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "ERRO: Node.js não encontrado. Rode ./00_PREPARAR_MAC_IOS_XCODE.command"
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo "node_modules não encontrado. Instalando dependências..."
  npm install --legacy-peer-deps --no-audit --fund=false
fi

echo "== Validando TypeScript sem bloquear =="
npx tsc --noEmit || true

echo ""
echo "== Gerando pasta ios/ limpa =="
rm -rf ios
npx expo prebuild -p ios --clean --non-interactive --no-install

echo ""
echo "== Ajustando iOS Deployment Target para 16.4 =="
python3 scripts/patch_ios_deployment_target.py || true

echo ""
echo "== Instalando Pods =="
cd ios
if command -v pod >/dev/null 2>&1; then
  pod install --repo-update || pod install
else
  echo "ERRO: CocoaPods não encontrado. Rode ./00_PREPARAR_MAC_IOS_XCODE.command"
  exit 1
fi
cd ..

echo ""
echo "== Reaplicando ajuste de Deployment Target no projeto Xcode =="
python3 scripts/patch_ios_deployment_target.py || true

echo ""
echo "== Abrindo no Xcode =="
if command -v xed >/dev/null 2>&1; then
  xed ios
else
  open ios/*.xcworkspace 2>/dev/null || open ios
fi

echo ""
echo "=========================================================="
echo " AGORA NO XCODE"
echo "=========================================================="
echo "1) Conecte o iPhone por cabo e toque em Confiar."
echo "2) No iPhone, ative Modo Desenvolvedor se o iOS pedir."
echo "3) No Xcode, clique no projeto BalcaoSeguro/Balcão Seguro."
echo "4) Target do app > Signing & Capabilities."
echo "5) Marque Automatically manage signing."
echo "6) Em Team, selecione seu Apple ID ou time Apple Developer."
echo "7) Se aparecer erro de Bundle Identifier, altere para algo único, exemplo:"
echo "   br.com.farmabolso.balcaoseguro.jean"
echo "8) No topo do Xcode, selecione seu iPhone físico."
echo "9) Clique no botão Run ▶."
echo ""
echo "Se seu iPhone está em iOS 27 beta e o Xcode não reconhecer,"
echo "instale/abra o Xcode beta compatível com esse iOS."

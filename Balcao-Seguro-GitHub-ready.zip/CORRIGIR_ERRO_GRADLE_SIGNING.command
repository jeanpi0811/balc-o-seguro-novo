#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "== Balcão Seguro: corrigir erro Gradle signingConfig =="

echo "1/4 Preservando keystore/propriedades antigas, se existirem..."
bash ./scripts/preserve_existing_keystore.sh || true

echo "2/4 Limpando cache Gradle antigo do projeto, se existir..."
if [ -d android ]; then
  rm -rf android/.gradle android/app/build android/build || true
fi

echo "3/4 Corrigindo build.gradle atual, se android/ existir..."
if [ -f android/app/build.gradle ]; then
  python3 ./scripts/patch_android_signing.py
else
  echo "android/app/build.gradle ainda não existe; ele será corrigido durante o próximo prebuild."
fi

echo "4/4 Pronto. Agora rode:"
echo "./10_GERAR_APK_AAB_COM_LOG.command"

#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — preparar tudo no macOS"
echo "============================================"

echo "== 1/4 Instalando dependências =="
npm install

echo "== 2/4 Ajustando Expo =="
npx expo install --fix || true

echo "== 3/4 Gerando Android nativo =="
npx expo prebuild -p android

echo "== 4/4 Gerando iOS nativo =="
if [[ "$(uname)" == "Darwin" ]]; then
  npx expo prebuild -p ios
  echo "Pastas android/ e ios/ prontas."
else
  echo "Pulando iOS porque este comando precisa rodar no macOS com Xcode."
fi
